<html>
    <head>
    <title>Print Detail</title>
    <style>
    th
    {
        font-size: 12px;
    }
    td
    {
        font-size: 12px;
    }
    </style>    
</head>
    
    <body>

<center><span>जिल्हा:- <?php echo e($jillaname[0]->area_name); ?></span><span style="margin-left:10px;">तालुका:- <?php echo e($talukaname[0]->area_name); ?></span><span style="margin-left:10px;">ग्रामपंचायत:- <?php echo e($gramname[0]->area_name); ?></span></center>
<table border=1>
    <tr>
        <!-- <th>अ. क्र. १ </th> -->
        <th>मालमतेचे वर्णन ३</th>
        <th>मालकाचे नाव ४</th>
        <th>भोगवटादाराचे नाव ५</th>
        <th>मिळकत बांधकामाचे वर्ष ६</th>
        <th>क्षेत्रफळ(चौरस फुट ७)</th>
        <th>क्षेत्रफळ(चौरस मीटर ८)</th>
        <th>रेडीरेकनर दर प्रति चो.मि.(रुपये) जमीन / बांधकाम ९</th>
        <!-- <th>रेडीरेकनर दर प्रति चो.मि.(रुपये) बांधकाम १०</th> -->
        <th>घसारा दर १०</th>
        <th>भारांक ११</th>
        <th>भांडवली मूल्य (रुपये) १२</th>
        <th>कराचा दर (पैसे) १३</th>
        <th>घरपट्टी कर १४</th>
        <th>दिवाबत्ती कर १५</th>
        <th>आरोग्य कर १६</th>
        <th>पाणीपट्टी कर १७</th>
        <th>स्पेशल पाणीपट्टी कर १८</th>
        <th>एकूण १९</th>
        <!--<th>अपिलाचे निकाल आणि त्यानंतर केलेले बदल २०</th>
        <th>२१</th>-->
        <th>Image</th>
        <th>Map Image</th>
    </tr>
    <tr>
        <td colspan="22"><b>अ. क्र. १ : </b> १ <b style="margin-left:20px;">आधार नं :</b><?php echo e($arr[0]->adhar); ?> <b style="margin-left:20px;">मोबाइल नं :</b><?php echo e($arr[0]->mbl); ?> <b style="margin-left:20px;">मालमत्ता क्र :</b>२ <b style="margin-left:20px;">उत्तर / दक्षिण :</b><?php echo e($arr[0]->north_south); ?> <b style="margin-left:20px;">पुर्व / पश्चिम  :</b><?php echo e($arr[0]->east_west); ?> <b style="margin-left:20px;">उत्तर  :</b><?php echo e($arr[0]->north); ?> <b style="margin-left:20px;">दक्षिण  :</b><?php echo e($arr[0]->south); ?> <b style="margin-left:20px;">पुर्व :</b><?php echo e($arr[0]->east); ?> <b style="margin-left:20px;">पश्चिम :</b><?php echo e($arr[0]->west); ?> <b style="margin-left:20px;">व्दार :</b><?php echo e($arr[0]->gate); ?> <b style="margin-left:20px;">शौचालय :</b><?php echo e($arr[0]->washroom); ?> <b style="margin-left:20px;">नळ कनेक्शन :</b><?php echo e($arr[0]->nal); ?> </td>
        

    </tr>
    <?php
    foreach($readyreknals as $bh)
    {
        $d=$bh->rate;
        
        $json_array=json_decode( preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $d),true);
        $amtarr=array();
        foreach($json_array as $key=>$arrays){
            foreach($arrays as $value){
                array_push($amtarr,$value);
            }
        }

    }
    foreach($bharank as $test)
    {
        $dee=$test->amt;
        //echo "bharank type=".$dee;
        $bhaarr1=json_decode( preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $dee),true);
        // $bhaarr1=array();
        // foreach($json_array1 as $key=>$arrays1){
        //     foreach($arrays1 as $value1){
        //         array_push($bhaarr1,$value1);
        //     }
        // }

    }
    foreach($additional as $ad)
    {
        $diva=$ad->divabatti_kar;
        $json_array2=json_decode( preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $diva),true);
        $divakar=array();
        foreach($json_array2 as $key=>$arrays2){
            foreach($arrays2 as $value2){
                array_push($divakar,$value2);
            }
        }

        $aarogy=$ad->aarogya_kar;
        $json_array3=json_decode( preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $aarogy),true);
        $aarogykar=array();
        foreach($json_array3 as $key=>$arrays3){
            foreach($arrays3 as $value3){
                array_push($aarogykar,$value3);
            }
        }
    }
   

?>
<?php
 $i=0;
 $j=1;
 $p=0;
 $q=1;
 $k=0;
 $l=1;
 $pp=1;
 $done=0;
 $karch=$additional[0]->karach_dar;
 $panipattikar=$additional[0]->panipatti_kar;
 $spepanipattikr=$additional[0]->panipatti_special_kar;
?>

    <?php $__currentLoopData = $survey; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       
    <?php 
    $k=$amtarr[$i];
    //$tbk=$bhaarr1[$p];
    
    $pname=$v->property_name;
    //echo $tbk;
    //echo $pname;
    ?>
    <tr>
        <td><?php echo e($v->varnana_name); ?> <?php if($v->property_name!=null): ?>
            (<?php echo e($v->property_name); ?>) <?php endif; ?></td>
        
        <?php if($v->ch_fu!=null || $v->ch_me!=null ): ?>
        <td><?php echo e($arr[0]->name); ?></td>
        <td><?php echo e($arr[0]->name2); ?></td>
        <td><?php echo e($v->yercon); ?></td>
        <td><?php echo e($v->ch_fu); ?></td>
        <?php
        $t=$v->ch_me;
        //$str=round($t,2);
        ?>
        <td><?php echo round($t,2);?></td>
        <?php if($k==$v->varnana_name && $v->ch_fu!=null || $v->ch_me!=null): ?>
        <td><?php echo $amtarr[$i+$j];?></td>
        <?php endif; ?>
       
        <!-- <td>Badakam</td> -->
        
        <?php
        $ty=$v->varnana_name;
        $conyr=$v->conyerage;
        $jilla=$jillaname[0]->id;
        $taluka=$talukaname[0]->id;
        $gram=$gramname[0]->id;
        // echo "jilla=".$jilla;
        // echo "taluka=".$taluka;
        // echo "gram=".$gram;
        $con=mysqli_connect("127.0.0.1","gayatriinfotech_user","*MA6YE_Wd8B]","gayatriinfotech_sl");
        mysqli_set_charset($con,'utf8');
        $sql="select * from ghasaras where types='$ty' and jilla='$jilla' and taluka='$taluka' and gram='$gram'";
        $result =mysqli_query($con,$sql);
        echo mysqli_error($con);
        while($rw=mysqli_fetch_assoc($result))
        {?>
        <td><?php echo $rw[$conyr];?></td>
        <?php
        }
        ?>
        <td><?php //var_dump($bhaarr1);

                foreach($bhaarr1 as $b)
                {
                    //echo $b;
                    if($b["type"] == $pname)
                        echo $b["amt"];
                }

        
        ?></td>
        <?php
        $ch_ft=$v->ch_fu;
        $d=$v->ch_me;
        $kl=round($d,2);
        $cho_me=$kl;
        $ready="";
        $ghasara="";
        $bharank="";
        $divabhatti="";
        $aarogytol="";
        
        if($k==$v->varnana_name && $v->ch_fu!=null || $v->ch_me!=null)
        {
            $ready=$amtarr[$i+$j];
        }
       
        $ty=$v->varnana_name;
        $conyr=$v->conyerage;
        $jilla=$jillaname[0]->id;
        $taluka=$talukaname[0]->id;
        $gram=$gramname[0]->id;
        $karacha_dar=$additional[0]->karach_dar;
        $con=mysqli_connect("127.0.0.1","gayatriinfotech_user","*MA6YE_Wd8B]","gayatriinfotech_sl");
        mysqli_set_charset($con,'utf8');
        $sql="select * from ghasaras where types='$ty' and jilla='$jilla' and taluka='$taluka' and gram='$gram'";
        $result =mysqli_query($con,$sql);
        echo mysqli_error($con);
        while($rw=mysqli_fetch_assoc($result))
        {
            $ghasara=$rw[$conyr];
        }
        foreach($bhaarr1 as $b)
        {
            //echo $b;
            if($b["type"] == $pname)
            $bharank=$b["amt"];
        }
        if($ch_ft > 0 && $ch_ft <=300)
        {
            $divabhatti=$divakar[1];
        }else if($ch_ft >300 && $ch_ft <=600)
        {
            $divabhatti=$divakar[3];
        } else if($ch_ft > 600)
        {
            $divabhatti=$divakar[5];
        }
        if($ch_ft > 0 && $ch_ft <=300)
        {
            $aarogytol=$aarogykar[1];
        }else if($ch_ft >300 && $ch_ft <=600)
        {
            $aarogytol=$aarogykar[3];
        } else if($ch_ft > 600)
        {
            $aarogytol=$aarogykar[5];
        }
        $bhandval=$cho_me*$ready*$ghasara*$bharank;
        $gharpatti=$bhandval*$karacha_dar/1000;
        $totalfinal=$gharpatti+$divabhatti+$aarogytol;
        //echo "MainTotal=".$totalfinal;
        $done+=$totalfinal;
        //echo "Total=".$done;
        ?>
       
        <td><?php echo round($bhandval,2);?></td>
        <?php if($pp=='1'): ?>
        <td><?php echo e($additional[0]->karach_dar); ?></td> 
        <?php else: ?>
        <td></td>
        <?php endif; ?>
        <td><?php echo round($gharpatti,2);?></td> 
        <?php
        $ch_ft=$v->ch_fu;
        if($ch_ft > 0 && $ch_ft <=300)
        {
        ?>
        <td><?php echo $divakar[1];?></td>
        <?php
        }else if($ch_ft >300 && $ch_ft <=600)
            {
        ?>
            <td><?php echo $divakar[3];?></td>
        <?php
        } else if($ch_ft > 600)
        {
        ?>
        <td><?php echo $divakar[5];?></td>
        <?php
        }
        ?>
         <?php
        $ch_ft=$v->ch_fu;
        if($ch_ft > 0 && $ch_ft <=300)
        {
        ?>
        <td><?php echo $aarogykar[1];?></td>
        <?php
        }else if($ch_ft >300 && $ch_ft <=600)
            {
        ?>
            <td><?php echo $aarogykar[3];?></td>
        <?php
        } else if($ch_ft > 600)
        {
        ?>
        <td><?php echo $aarogykar[5];?></td>
        <?php
        }
        ?>
        <?php if($pp=='1'): ?>
        <td><?php echo e($additional[0]->panipatti_kar); ?></td>
        <td><?php echo e($additional[0]->panipatti_special_kar); ?></td>
        <?php else: ?> 
        <td></td>
        <td></td>
        <?php endif; ?>

        <td><?php echo round($totalfinal,2); ?></td> 
        <td><img src="<?php echo e(asset('image')); ?>/<?php echo e($arr[0]->img); ?>" height="50px" width="80px"></td> 

        <td><img src="<?php echo e(asset('image')); ?>/<?php echo e($arr[0]->mapimg); ?>" height="50px" width="80px"></td> 
        <?php else: ?>
      <td></td>
       <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td> 
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td> 
        <td></td>
        <td></td>
         
        
      <?php endif; ?>
        
     
       
        
    </tr>
    
    <?php
    
    $i++;
    $j++;
    $p++;
    $q++;
    $k++;
    $l++;
    $pp++;
    ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <tr><td colspan="16"><p align="right"><b> एकूण :- </b></p></td><td colspan="3"><?php echo round($done,2);?></td></tr>
    <tr><td colspan="16"><p align="right"><b> एकूण + कराचा दर + पाणीपट्टी कर + स्पेशल पाणीपट्टी कर :- </b></p></td><td colspan="3"><?php $tt=round($done,2); echo $tt;?> + <?php echo $karch;?> + <?php echo $panipattikar;?> + <?php echo $spepanipattikr;?></td></tr>
    <tr><td colspan="16"><p align="right"><b> एकूण :- </b></p></td><td colspan="3"><?php echo round($tt+$karch+$panipattikar+$spepanipattikr,2);?></td></tr>
  
    
</table>
</body>
</html>
<?php /**PATH /home/gayatriinfotech/sl/resources/views/backend/printdetails.blade.php ENDPATH**/ ?>