<?php
foreach($bharanks as $bh)
{
    $d=$bh->amt;
    $json_array=json_decode( preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $d),true);
    $arr1=array();
    foreach($json_array as $key=>$arrays){
        foreach($arrays as $value){
            
                array_push($arr1,$value);
            
        }
    }
}
foreach($readyreknals as $bh)
{
    $d=$bh->rate;
    //var_dump($d);
    //exit();
    $arr2=json_decode( preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $d),true);
    // var_dump($json_array);
    // exit();
    // $arr2=array();
    // foreach($json_array as $key=>$arrays){
    //     foreach($arrays as $value){
            
    //             array_push($arr2,$value);
            
    //     }
    // }
    
}

$arr3=array();
foreach($ghasaras as $k)
{
    
    $data=array(
        "one"=>$k->one,
        "two"=>$k->two,
        "three"=>$k->three,
        "four"=>$k->four,
        "five"=>$k->five,
        "six"=>$k->six,
        "seven"=>$k->seven,
        "eight"=>$k->eight,
        "greater_than_sixty"=>$k->greater_than_sixty
    );
    array_push($arr3,$data);
}


foreach($additional_kar as $d)
{
    $dkk=$d->divabatti_kar;
   // var_dump($dkk);
    $jsa=json_decode( preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $dkk),true);
   $arr4=array();
    foreach($jsa as $key=>$arrays){
        foreach($arrays as $value){
            
                array_push($arr4,$value);
            
        }
    }
   
    
    
}
//exit();
foreach($additional_kar as $d)
{
    $dk=$d->aarogya_kar;
    $json_array=json_decode( preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $dk),true);
    $arr5=array();
    foreach($json_array as $key=>$arrays){
        foreach($arrays as $value){
            
                array_push($arr5,$value);
            
        }
    }
}
//var_dump($arr4);
//exit();
$opt=$varnan."::".$additional[0]->panipatti_kar."::".$additional[0]->panipatti_special_kar."::".$arr4[1]."::".$arr4[3]."::".$arr4[5]."::".$arr5[1]."::".$arr5[3]."::".$arr5[5]."::".$arr1[1]."::".$arr1[3]."::".$arr1[5]."::";

for($j=0; $j<sizeof($arr2); $j++)
{
    $opt.=$arr2[$j]["rates"]."::";
    $opt.=$arr2[$j]["karach_dar"]."::";
}
$opt."::".$arr1[1]."::".$arr1[3]."::".$arr1[5]."::";
for($i=0; $i<sizeof($arr3); $i++)
{
    $opt.= $arr3[$i]["one"]."::";
    $opt.= $arr3[$i]["two"]."::";
    $opt.= $arr3[$i]["three"]."::";
    $opt.= $arr3[$i]["four"]."::";
    $opt.= $arr3[$i]["five"]."::";
    $opt.= $arr3[$i]["six"]."::";
    $opt.= $arr3[$i]["seven"]."::";
    $opt.= $arr3[$i]["eight"]."::";
    $opt.= $arr3[$i]["greater_than_sixty"]."::";
    
}
echo $opt;
// $OTPUT=$arr1[1]."::".$arr1[3]."::".$arr1[5]."::".$arr2[1]."::".$arr2[3]."::".$arr2[5]."::".$arr2[7]."::".$arr2[9]."::";
// for($j=0; $j>sizeof($arr2); $i++)
// {
//     $OTPUT.=$arr2[$j+1];
// }
// 
// //appen append
// echo $OTPUT;
// exit();

//echo $arr1[1]."::".$arr1[3]."::".$arr1[5]."::".$arr2[1]."::".$arr2[3]."::".$arr2[5]."::".$arr2[7]."::".$arr2[9]."::".$arr3[0]["one"]."::".$arr3[0]["two"]."::".$arr3[0]["three"]."::".$arr3[0]["four"]."::".$arr3[0]["five"]."::".$arr3[0]["six"]."::".$arr3[0]["seven"]."::".$arr3[0]["eight"]."::".$arr3[0]["greater_than_sixty"]."::".$arr3[1]["one"]."::".$arr3[1]["two"]."::".$arr3[1]["three"]."::".$arr3[1]["four"]."::".$arr3[1]["five"]."::".$arr3[1]["six"]."::".$arr3[1]["seven"]."::".$arr3[1]["eight"]."::".$arr3[1]["greater_than_sixty"]."::".$arr3[2]["one"]."::".$arr3[2]["two"]."::".$arr3[2]["three"]."::".$arr3[2]["four"]."::".$arr3[2]["five"]."::".$arr3[2]["six"]."::".$arr3[2]["seven"]."::".$arr3[2]["eight"]."::".$arr3[2]["greater_than_sixty"]."::".$arr3[3]["one"]."::".$arr3[3]["two"]."::".$arr3[3]["three"]."::".$arr3[3]["four"]."::".$arr3[3]["five"]."::".$arr3[3]["six"]."::".$arr3[3]["seven"]."::".$arr3[3]["eight"]."::".$arr3[3]["greater_than_sixty"]."::".$arr3[4]["one"]."::".$arr3[4]["two"]."::".$arr3[4]["three"]."::".$arr3[4]["four"]."::".$arr3[4]["five"]."::".$arr3[4]["six"]."::".$arr3[4]["seven"]."::".$arr3[4]["eight"]."::".$arr3[4]["greater_than_sixty"]."::".$arr4[1]."::".$arr4[3]."::".$arr4[5]."::".$additional[0]->panipatti_kar."::".$additional[0]->panipatti_special_kar."::".$arr5[1]."::".$arr5[3]."::".$arr5[5];
?><?php /**PATH /home/gayatriinfotech/rental.gayatriinfotech.in/resources/views/backend/display_all_points.blade.php ENDPATH**/ ?>