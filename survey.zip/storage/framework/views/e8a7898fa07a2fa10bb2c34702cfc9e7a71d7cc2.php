</div>

			<aside id="sidebar-right" class="sidebar-right">
				<div class="nano">
					<div class="nano-content">
						<a href="#" class="mobile-close visible-xs">
							Collapse <i class="fa fa-chevron-right"></i>
						</a>
			
						<div class="sidebar-right-wrapper">
			
							<div class="sidebar-widget widget-calendar">
								<h6>Upcoming Tasks</h6>
								<div data-plugin-datepicker data-plugin-skin="dark" ></div>
			
								<ul>
									<li>
										<time datetime="2014-04-19T00:00+00:00">04/19/2014</time>
										<span>Company Meeting</span>
									</li>
								</ul>
							</div>
			
							<div class="sidebar-widget widget-friends">
								<h6>Friends</h6>
								<ul>
									<li class="status-online">
										<figure class="profile-picture">
											<img src="<?php echo e(asset('backend/assets/images/!sample-user.jpg')); ?>" alt="Joseph Doe" class="img-circle">
										</figure>
										<div class="profile-info">
											<span class="name">Joseph Doe Junior</span>
											<span class="title">Hey, how are you?</span>
										</div>
									</li>
									<li class="status-online">
										<figure class="profile-picture">
											<img src="<?php echo e(asset('backend/assets/images/!sample-user.jpg')); ?>" alt="Joseph Doe" class="img-circle">
										</figure>
										<div class="profile-info">
											<span class="name">Joseph Doe Junior</span>
											<span class="title">Hey, how are you?</span>
										</div>
									</li>
									<li class="status-offline">
										<figure class="profile-picture">
											<img src="<?php echo e(asset('backend/assets/images/!sample-user.jpg')); ?>" alt="Joseph Doe" class="img-circle">
										</figure>
										<div class="profile-info">
											<span class="name">Joseph Doe Junior</span>
											<span class="title">Hey, how are you?</span>
										</div>
									</li>
									<li class="status-offline">
										<figure class="profile-picture">
											<img src="<?php echo e(asset('backend/assets/images/!sample-user.jpg')); ?>" alt="Joseph Doe" class="img-circle">
										</figure>
										<div class="profile-info">
											<span class="name">Joseph Doe Junior</span>
											<span class="title">Hey, how are you?</span>
										</div>
									</li>
								</ul>
							</div>
			
						</div>
					</div>
				</div>
			</aside>
		</section>

		<!-- Vendor -->
		<script src="<?php echo e(asset('backend/assets/vendor/jquery/jquery.js')); ?>"></script>
		<script src="<?php echo e(asset('backend/assets/vendor/jquery-browser-mobile/jquery.browser.mobile.js')); ?>"></script>
		<script src="<?php echo e(asset('backend/assets/vendor/bootstrap/js/bootstrap.js')); ?>"></script>
		<script src="<?php echo e(asset('backend/assets/vendor/nanoscroller/nanoscroller.js')); ?>"></script>
		<script src="<?php echo e(asset('backend/assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js')); ?>"></script>
		<script src="<?php echo e(asset('backend/assets/vendor/magnific-popup/magnific-popup.js')); ?>"></script>
		<script src="<?php echo e(asset('backend/assets/vendor/jquery-placeholder/jquery.placeholder.js')); ?>"></script>
		
		<!-- Specific Page Vendor -->
		<script src="<?php echo e(asset('backend/assets/vendor/select2/select2.js')); ?>"></script>
		<script src="<?php echo e(asset('backend/assets/vendor/jquery-datatables/media/js/jquery.dataTables.js')); ?>"></script>
		<script src="<?php echo e(asset('backend/assets/vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js')); ?>"></script>
		<script src="<?php echo e(asset('backend/assets/vendor/jquery-datatables-bs3/assets/js/datatables.js')); ?>"></script>
		
		<!-- Theme Base, Components and Settings -->
		<script src="<?php echo e(asset('backend/assets/javascripts/theme.js')); ?>"></script>
		
		<!-- Theme Custom -->
		<script src="<?php echo e(asset('backend/assets/javascripts/theme.custom.js')); ?>"></script>
		
		<!-- Theme Initialization Files -->
		<script src="<?php echo e(asset('backend/assets/javascripts/theme.init.js')); ?>"></script>


		<!-- Examples -->
		<script src="<?php echo e(asset('backend/assets/javascripts/tables/examples.datatables.default.js')); ?>"></script>
		<script src="<?php echo e(asset('backend/assets/javascripts/tables/examples.datatables.row.with.details.js')); ?>"></script>
		<script src="<?php echo e(asset('backend/assets/javascripts/tables/examples.datatables.tabletools.js')); ?>"></script>
	</body>
</html><?php /**PATH H:\xampp\htdocs\lavanya\survey\resources\views/backend/footer.blade.php ENDPATH**/ ?>