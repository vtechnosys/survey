
<?php $__env->startSection('index-content'); ?>

				<section role="main" class="content-body">
					<header class="page-header">
						<h2>मिळकतीचे वर्णन फॉर्म </h2>
					
						<div class="right-wrapper pull-right">
							<ol class="breadcrumbs">
								<li>
									<a href="/">
										<i class="fa fa-home"></i>
									</a>
								</li>
								<li><span>जिल्हा</span></li>
								<li><span>तालुका</span></li>
							</ol>
					
							<a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
						</div>
					</header>

					<!-- start: page -->
					<div class="row">
						<div class="col-md-10">
							<form id="form" action="<?php echo e(route('varnan.store')); ?>" class="form-horizontal" method="post">
							<?php echo csrf_field(); ?>
								<section class="panel">
									<header class="panel-heading">
										<div class="panel-actions">
											<a href="#" class="fa fa-caret-down"></a>
											<a href="#" class="fa fa-times"></a>
										</div>

										<h2 class="panel-title">मिळकतीचे वर्णन फॉर्म</h2>
										<!--<p class="panel-subtitle">
											Basic validation will display a label with the error after the form control.
										</p>-->
									</header>
									<div class="panel-body">
										<div class="form-group">
											<label class="col-sm-3 control-label">मिळकतीचे वर्णन नाव<span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" 
												name="मिळकतीचे_वर्णन_नाव" class="form-control" required>
												<?php $__errorArgs = ['मिळकतीचे_वर्णन_नाव'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
												<font size="3" color="red"><?php echo e($message); ?></font>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>	
											</div>
										</div>
										
										
									</div>
									<footer class="panel-footer">
										<div class="row">
											<div class="col-sm-9 col-sm-offset-3">
												<button class="btn btn-primary" type="submit">Submit</button>
												<!--<button type="reset" class="btn btn-default">Reset</button>-->
											</div>
										</div>
									</footer>
								</section>
							</form>
						</div>
						
					</div>
					<!-- end: page -->
					<!-- start: page -->
					<section class="panel">
							<header class="panel-heading">
								<div class="panel-actions">
									<a href="#" class="fa fa-caret-down"></a>
									<a href="#" class="fa fa-times"></a>
								</div>
						
								<h2 class="panel-title">मिळकतीचे वर्णन तपशील</h2>
							</header>
							<div class="panel-body">
								<table class="table table-bordered table-striped mb-none" id="datatable-default">
									<thead>
										<tr>
											<th>मिळकतीचे वर्णन क्र. </th>
											<th>मिळकतीचे वर्णन नाव</th>
											
											<th>Status</th>
											<th>Edit</th>
											
										</tr>
									</thead>
									<tbody>
									<?php
									$i=1;
									?>
									<?php $__currentLoopData = $varnan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr class="gradeX">
											<td><?php echo e($a->id); ?></td>
											<td><?php echo e($a->name); ?></td>
											
											<?php 
											$s=$a->status;
											if($s=='active')
											{
											?>
											<td><a href="/statuschkvarnan/<?php echo e($a->id); ?>" class="btn btn-success" id="statuschk" value="<?php echo e($a->id); ?>"><?php echo e($a->status); ?></a></td>
											<?php
											}else{
											?>
											<td><a href="/statuschkvarnan/<?php echo e($a->id); ?>" class="btn btn-warning" id="statuschk" value="<?php echo e($a->id); ?>"><?php echo e($a->status); ?></a></td>
											<?php
											}
											?>
											<td class="actions">
												
												<button class="btn btn-primary"><a href="<?php echo e(route('varnan.edit',$a->id)); ?>" class="on-default edit-row" style="text-decoration:none;color:white;">Edit</a></button></td>
												<!--<td><form action="<?php echo e(route('varnan.destroy',$a->id)); ?>" method="post">
												<?php echo csrf_field(); ?>
												<?php echo method_field('DELETE'); ?>
												<input type="submit" class="on-default remove-row" value="Delete">
												</form>
											</td>
											<td class="actions">
												
												<a href="<?php echo e(route('varnan.show',$a->id)); ?>" class="on-default edit-row"><button>Show</button></a></td>-->
									</tr>
									<?php
									$i++
									?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									
									</tbody>
								</table>
							</div>
						</section>
						
				</section>
			<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\sl\resources\views/backend/varnan.blade.php ENDPATH**/ ?>