
<?php $__env->startSection('index-content'); ?>

				<section role="main" class="content-body">
					<header class="page-header">
						<h2>ग्रामपंचायत तपशील</h2>
					
						<div class="right-wrapper pull-right">
							<ol class="breadcrumbs">
								<li>
									<a href="/">
										<i class="fa fa-home"></i>
									</a>
								</li>
								<li><span>टेबल</span></li>
								<li><span>ग्रामपंचायत</span></li>
							</ol>
					
							<a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
						</div>
					</header>

					<!-- start: page -->
						<section class="panel">
							<header class="panel-heading">
								<div class="panel-actions">
									<a href="#" class="fa fa-caret-down"></a>
									<a href="#" class="fa fa-times"></a>
								</div>
						
								<h2 class="panel-title">ग्रामपंचायत तपशील </h2>
							</header>
							<div class="panel-body">
								<table class="table table-bordered table-striped mb-none" id="datatable-default">
									<thead>
										<tr>
											<th>ग्रामपंचायत क्र.</th>
											<th>तालुका नाव</th>
											<th>ग्रामपंचायत नाव</th>
											<th>Status</th>
											<th>Edit</th>
											<th>Delete</th>
										
										</tr>
									</thead>
									<tbody>
									<?php $__currentLoopData = $area_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr class="gradeX">
										<?php if(sizeof($a[1])>0): ?>
												<?php $__currentLoopData = $a[1]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<td><?php echo e($p->id); ?></td>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											
											<?php endif; ?>
											<?php if(sizeof($a[1])>0): ?>
												<?php $__currentLoopData = $a[1]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<?php if($p->parent_id==$a[0]->id): ?>
												<td><?php echo e($a[0]->area_name); ?></td>
												
												<?php endif; ?>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											
											<?php endif; ?>
										
											
											<?php if(sizeof($a[1])>0): ?>
												<?php $__currentLoopData = $a[1]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<td><?php echo e($p->area_name); ?></td>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											
											<?php endif; ?>
											
											<?php if(sizeof($a[1])>0): ?>
												<?php $__currentLoopData = $a[1]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<?php if($p->parent_id==$a[0]->id): ?>
												<td><?php echo e($a[0]->status); ?></td>
												
												<?php endif; ?>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											
											<?php endif; ?>
											<?php if(sizeof($a[1])>0): ?>
												<?php $__currentLoopData = $a[1]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<td class="actions">
													<a href="gramedit/<?php echo e($p->id); ?>" class="on-default edit-row"><button>Edit</button></a>
												</td>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											
											<?php endif; ?>
											
											<?php if(sizeof($a[1])>0): ?>
												<?php $__currentLoopData = $a[1]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<td class="actions">
													<form action="gramremove/<?php echo e($p->id); ?>" method="post">
													<?php echo csrf_field(); ?>
													
													<button type="submit">Delete</button></form>
													
												</td>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											
											<?php endif; ?>
											
											
									</tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</tbody>
								</table>
							</div>
						</section>
						</section>
						
						
			<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xampp\htdocs\lavanya\survey\resources\views/backend/gram_view.blade.php ENDPATH**/ ?>