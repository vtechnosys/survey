
<?php $__env->startSection('index-content'); ?>

				<section role="main" class="content-body">
					<header class="page-header">
						<h2>वापरकर्ता तपशील</h2>
					
						<div class="right-wrapper pull-right">
							<ol class="breadcrumbs">
								<li>
									<a href="/">
										<i class="fa fa-home"></i>
									</a>
								</li>
								<li><span>टेबल</span></li>
								<li><span>वापरकर्ता</span></li>
							</ol>
					
							<a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
						</div>
					</header>

					<!-- start: page -->
						<section class="panel">
							<header class="panel-heading">
								<div class="panel-actions">
									<a href="#" class="fa fa-caret-down"></a>
									<a href="#" class="fa fa-times"></a>
								</div>
						
								<h2 class="panel-title">वापरकर्ता तपशील</h2>
							</header>
							<div class="panel-body">
								<table class="table table-bordered table-striped mb-none" id="datatable-default">
									<thead>
										<tr>
											<th>वापरकर्ता क्र.</th>
											<th>वापरकर्ता नाव</th>
											<th>मोबाईल नंबर</th>
											<th>पासवर्ड</th>
											<th>Status</th>
										</tr>
									</thead>
									<tbody>
									<tr class="gradeX">
											<td><?php echo e($regi->id); ?></td>
											<td><?php echo e($regi->name); ?></td>
											<td><?php echo e($regi->mobile); ?></td>
											<td><?php echo e($regi->password); ?></td>
											<td><?php echo e($regi->status); ?></td>
											
									</tr>
									
									</tbody>
								</table>
							</div>
						</section>
						</section>
						
						
			<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gayatriinfotech/sl/resources/views/backend/register_show.blade.php ENDPATH**/ ?>