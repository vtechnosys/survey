<?php

foreach($bharanks as $bh)
{
    
    $d=$bh->amt;
    $json_array=json_decode( preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $d),true);
    $arr1=array();
    foreach($json_array as $key=>$arrays){
        foreach($arrays as $value){
            
                array_push($arr1,$value);
            
        }
    }
    var_dump($arr1);
}

exit();
$arr2=array();
foreach($readyreknals as $bh)
{
    $d=$bh->rate;
    $json_array=json_decode( preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $d),true);
    
    foreach($json_array as $key=>$arrays){
        foreach($arrays as $value){
            
                array_push($arr2,$value);
            
        }
    }
    //var_dump($arr2);
    
    
}

 echo $arr1[1]."::".$arr1[3]."::".$arr1[5]."::".$arr2[1]."::".$arr2[3]."::".$arr2[5]."::".$arr2[7]."::".$arr2[9];
?><?php /**PATH C:\xampp\htdocs\laravel\sl\resources\views/backend/getalldetails.blade.php ENDPATH**/ ?>