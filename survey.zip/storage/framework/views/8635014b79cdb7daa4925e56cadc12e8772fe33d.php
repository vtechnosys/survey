
<?php $__env->startSection('index-content'); ?>
				<section role="main" class="content-body">
					<header class="page-header">
						<h2>तालुका तपशील</h2>
					
						<div class="right-wrapper pull-right">
							<ol class="breadcrumbs">
								<li>
									<a href="/">
										<i class="fa fa-home"></i>
									</a>
								</li>
								<li><span>टेबल</span></li>
								<li><span>तालुका</span></li>
							</ol>
					
							<a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
						</div>
					</header>

					<!-- start: page -->
						<section class="panel">
							<header class="panel-heading">
								<div class="panel-actions">
									<a href="#" class="fa fa-caret-down"></a>
									<a href="#" class="fa fa-times"></a>
								</div>
						
								<h2 class="panel-title">मिळकतीचे वर्णन तपशील</h2>
							</header>
							<div class="panel-body">
								<table class="table table-bordered table-striped mb-none" id="datatable-default">
									<thead>
										<tr>
											<th>मिळकतीचे वर्णन क्र. </th>
											<th>मिळकतीचे वर्णन नाव</th>
											
											<th>Status</th>
											<th>Edit</th>
											<th>Show</th>
										</tr>
									</thead>
									<tbody>
									<?php
									$i=1;
									?>
									<?php $__currentLoopData = $varnan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr class="gradeX">
											<td><?php echo e($a->id); ?></td>
											<td><?php echo e($a->name); ?></td>
											
											<td><?php echo e($a->status); ?></td>
											<!--<td class="actions">
												
												<a href="<?php echo e(route('varnan.edit',$a->id)); ?>" class="on-default edit-row"><button>Edit</button></a></td>
												<td><form action="<?php echo e(route('varnan.destroy',$a->id)); ?>" method="post">
												<?php echo csrf_field(); ?>
												<?php echo method_field('DELETE'); ?>
												<input type="submit" class="on-default remove-row" value="Delete">
												</form>
											</td>-->
											<td class="actions">
												
												<a href="<?php echo e(route('varnan.show',$a->id)); ?>" class="on-default edit-row"><button>Show</button></a></td>
									</tr>
									<?php
									$i++
									?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									
									</tbody>
								</table>
							</div>
						</section>
						
						
						
						
					<!-- end: page -->
				</section>
			<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\survey\resources\views/backend/varnan_view.blade.php ENDPATH**/ ?>