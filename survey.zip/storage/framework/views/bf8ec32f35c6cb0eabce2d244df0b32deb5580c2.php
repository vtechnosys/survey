
<?php $__env->startSection('index-content'); ?>

				<section role="main" class="content-body">
					<header class="page-header">
						<h2>सर्वेक्षण तपशील</h2>
					
						<div class="right-wrapper pull-right">
							<ol class="breadcrumbs">
								<li>
									<a href="/">
										<i class="fa fa-home"></i>
									</a>
								</li>
								<li><span>टेबल</span></li>
								<li><span>सर्वेक्षण</span></li>
							</ol>
					
							<a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
						</div>
					</header>

					<!-- start: page -->
						<section class="panel">
							<header class="panel-heading">
								<div class="panel-actions">
									<a href="#" class="fa fa-caret-down"></a>
									<a href="#" class="fa fa-times"></a>
								</div>
						
								<h2 class="panel-title">सर्वेक्षण तपशील</h2>
							</header>
							<div class="panel-body">
								<table class="table table-bordered table-striped mb-none">
									<thead>
										<tr>
											<th>सर्वेक्षण क्र. </th>
											<th>तालुका</th>
											<th>ग्रामपंचायत</th>
											
											<th>स्वयंघोषणापत्र  करुन देणार</th>
											<th class="hidden-phone">स्वयंघोषणापत्र  करुन घेणार</th>
											<th class="hidden-phone">भोगवटदाराचे नांव</th>
											<th class="hidden-phone">सिटीसव्‍ह मिळकत धारकाचे नांव </th>
											<th class="hidden-phone">मोबाइल नं</th>
											<th class="hidden-phone">आधार नं</th>
											<!--<th class="hidden-phone">जुना मिळकत क्र</th>
											<th class="hidden-phone">सि.सि नं.</th>
											<th class="hidden-phone">सि. सि. चैा मि.</th>
											<th class="hidden-phone">गट नं.</th>
											<th class="hidden-phone">प्लॉट नं.</th>
											<th class="hidden-phone">बांधकाम वर्ष</th>
											<th class="hidden-phone">उत्तर / दक्षिण</th>
											<th class="hidden-phone">पुर्व / पश्चिम</th>
											
											<th class="hidden-phone">उत्तर</th>
											<th class="hidden-phone">दक्षिण</th>
											<th class="hidden-phone">पुर्व</th>
											<th class="hidden-phone">पश्चिम</th>
											<th class="hidden-phone">व्दार</th>
											<th class="hidden-phone">Status</th>-->
											
											
										</tr>
									</thead>
									<tbody>
										<?php $__currentLoopData = $survey_i; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<tr class="gradeX">
											<td><?php echo e($sur->id); ?></td>
											<td><?php echo e($sur->area_name); ?></td>
											<td><?php echo e($sur->gram_id); ?></td>
											
											<td class="center hidden-phone"><?php echo e($sur->name); ?></td>
											<td class="center hidden-phone"><?php echo e($sur->gram_name); ?></td>
											<td class="center hidden-phone"><?php echo e($sur->name2); ?></td>
											<td class="center hidden-phone"><?php echo e($sur->survey_name); ?></td>
											<td class="center hidden-phone"><?php echo e($sur->mbl); ?></td>
											<td class="center hidden-phone"><?php echo e($sur->adhar); ?></td>
											<!--<td class="center hidden-phone"><?php echo e($sur->old_tax_no); ?></td>
											<td class="center hidden-phone"><?php echo e($sur->s_s_no); ?></td>
											<td class="center hidden-phone"><?php echo e($sur->s_s_m); ?></td>
											<td class="center hidden-phone"><?php echo e($sur->group_no); ?></td>
											<td class="center hidden-phone"><?php echo e($sur->plot_no); ?></td>
											<td class="center hidden-phone"><?php echo e($sur->yr_const); ?></td>
											<td class="center hidden-phone"><?php echo e($sur->north_south); ?></td>
											<td class="center hidden-phone"><?php echo e($sur->east_west); ?></td>
											
											
											<td class="center hidden-phone"><?php echo e($sur->north); ?></td>
											<td class="center hidden-phone"><?php echo e($sur->south); ?></td>
											<td class="center hidden-phone"><?php echo e($sur->east); ?></td>
											<td class="center hidden-phone"><?php echo e($sur->west); ?></td>
											<td class="center hidden-phone"><?php echo e($sur->gate); ?></td>
											<td class="center hidden-phone"><?php echo e($sur->status); ?></td>-->
											
										</tr>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</tbody>
								</table>
								<table>
								<tr>
											<th>मिळकतीचे वर्णन</th>
											<th>चाै.फुट</th>
											<th>चाै.मि.</th>
											<th>रेडिरेकनरचे दर</th>
											<th>घसार दर</th>
											<th>भारांक</th>
											<th>एकुण कर</th>
								</tr>
								
								
								<?php $__currentLoopData = $k; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
								 <td>१. झोपडीचे घर किंवा मातीचे घर</td>
								<td><?php echo e($l->ch_fu); ?></td>
								<td><?php echo e($l->ch_me); ?></td>
								<td><?php echo e($l->ready); ?></td>
								<td><?php echo e($l->gasar); ?></td>
								<td><?php echo e($l->bharank); ?></td>
								<td><?php echo e($l->total); ?></td>
								</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								
								
								
								</table>
							</div>
						</section>
						</section>
						
						
			<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xampp\htdocs\lavanya\survey\resources\views/backend/survey_show.blade.php ENDPATH**/ ?>