
<?php $__env->startSection('index-content'); ?>

				<section role="main" class="content-body">
					<header class="page-header">
						<h2>Survey Details</h2>
					
						<div class="right-wrapper pull-right">
							<ol class="breadcrumbs">
								<li>
									<a href="/">
										<i class="fa fa-home"></i>
									</a>
								</li>
								<li><span>Table</span></li>
								<li><span>Survey Details</span></li>
							</ol>
					
							<a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
						</div>
					</header>

					<!-- start: page -->
						<section class="panel">
							<header class="panel-heading">
								<div class="panel-actions">
									<a href="#" class="fa fa-caret-down"></a>
									<a href="#" class="fa fa-times"></a>
								</div>
						
								<h2 class="panel-title">Survey Details</h2>
							</header>
							<div class="panel-body">
								<table class="table table-bordered table-striped mb-none" id="datatable-default">
									<thead>
										<tr>
											<th>Id</th>
											<th>Survey Name</th>
											<th>Income Type</th>
											<th>Sq.ft</th>
											<th>Sq.mtr</th>
											<th>Redeemer Rates</th>
											<th>Depreciation rate</th>
											<th>Weighted rate</th>
											<th>Total</th>
											<th>Delete</th>
											<th>Update</th>
											<th>Show</th>
										</tr>
									</thead>
									<tbody>
									<?php $__currentLoopData = $survey_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr class="gradeX">
											<td><?php echo e($a->id); ?></td>
											<td><?php echo e($a->name); ?></td>
											<td><?php echo e($a->type); ?></td>
											<td><?php echo e($a->sq_ft); ?></td>
											<td><?php echo e($a->sq_mtr); ?></td>
											<td><?php echo e($a->readyreknal); ?></td>
											<td><?php echo e($a->depression); ?></td>
											<td><?php echo e($a->bharank); ?></td>
											<td><?php echo e($a->total); ?></td>
											<td class="actions">
												
												<a href="<?php echo e(route('survey_detail.edit',$a->id)); ?>" class="on-default edit-row"><button>Edit</button></a></td>
												<td><form action="<?php echo e(route('survey_detail.destroy',$a->id)); ?>" method="post">
												<?php echo csrf_field(); ?>
												<?php echo method_field('DELETE'); ?>
												<input type="submit" class="on-default remove-row" value="Delete">
												</form>
											</td>
											<td class="actions">
												
												<a href="<?php echo e(route('survey_detail.show',$a->id)); ?>" class="on-default edit-row"><button>Show</button></a></td>
									</tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</tbody>
								</table>
							</div>
						</section>
						</section>
						
						
			<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xampp\htdocs\lavanya\survey\resources\views/backend/survey_detail_view.blade.php ENDPATH**/ ?>