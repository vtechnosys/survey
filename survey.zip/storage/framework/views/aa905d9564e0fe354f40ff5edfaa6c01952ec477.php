
<?php $__env->startSection('index-content'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\survey\resources\views/backend/index.blade.php ENDPATH**/ ?>