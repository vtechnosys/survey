<?php
$str="<option>select</option>";
foreach($jillaid as $j)
{
    $str.="<option value='$j->id'>".$j->area_name."</option>";
}
echo $str;
?><?php /**PATH /home/gayatriinfotech/rental.gayatriinfotech.in/resources/views/backend/display_taluka_id.blade.php ENDPATH**/ ?>