<html>
    <head>
    <title>Print Detail</title>
    <style>
    th
    {
        font-size: 12px;
    }
    td
    {
        font-size: 12px;
    }
    </style>    
</head>
    
    <body>
<?php $__currentLoopData = $arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<center><span>जिल्हा:- <?php echo e($jillaname[0]->area_name); ?></span><span style="margin-left:10px;">तालुका:- <?php echo e($talukaname[0]->area_name); ?></span><span style="margin-left:10px;">ग्रामपंचायत:- <?php echo e($gramname[0]->area_name); ?></span></center>
<table border=1>
    <tr>
        <th>अ. क्र. १ </th>
        <th>मालमता क्रमांक २</th>
        <th>मालमतेचे वर्णन ३</th>
        <th>मालकाचे नाव ४</th>
        <th>भोगवटादाराचे नाव ५</th>
        <th>मिळकत बांधकामाचे वर्ष ६</th>
        <th>क्षेत्रफळ(चौरस फुट ७)</th>
        <th>क्षेत्रफळ(चौरस मीटर ८)</th>
        <th>रेडीरेकनर दर प्रति चो.मि.(रुपये) जमीन ९</th>
        <th>रेडीरेकनर दर प्रति चो.मि.(रुपये) बांधकाम १०</th>
        <th>घसारा दर ११</th>
        <th>भारांक १२</th>
        <th>भांडवली मूल्य (रुपये) १३</th>
        <th>कराचा दर (पैसे) १४</th>
        <th>घरपट्टी कर १५</th>
        <th>दिवाबत्ती कर १६</th>
        <th>आरोग्य कर १७</th>
        <th>पाणीपट्टी कर १८</th>
        <th>स्पेशल पाणीपट्टी कर १९</th>
        <th>एकूण २०</th>
        <th>अपिलाचे निकाल आणि त्यानंतर केलेले बदल २१</th>
        <th>२२</th>
    </tr>
    <tr>
        <td>10</td>
        <td>9</td>
        <td>उ.द. पु.प</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>

    </tr>
    <?php
    $yr_con="";

    ?>
    <?php $__currentLoopData = $k; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
    $yr_con=$arr[0]->yr_const;
    ?>
    <tr>
        <td></td>
        <td></td>
        
        
       
        <td><?php echo e($v->varnana_name); ?></td>
       <?php
       if($v->ch_fu!=null || $v->ch_me!=null )
       {
       ?>
        <td><?php echo e($arr[0]->name); ?></td>
        <td><?php echo e($arr[0]->name2); ?></td>
        <td><?php echo $yr_con;?></td>
        <td><?php echo e($v->ch_fu); ?></td>
        <td><?php echo e($v->ch_me); ?></td>
        <td><?php echo e($v->ready); ?></td>
        <td></td>
        <td><?php echo e($v->ghasara); ?></td>
        <td><?php echo e($v->bharank); ?></td>
        <td></td>
        
        <td><?php echo e($additional[0]->karach_dar); ?></td> 
        <td></td> 
        
        <td><?php echo e($additional[0]->divabatti_kar); ?></td>
        <td><?php echo e($additional[0]->aarogya_kar); ?></td>
        <td><?php echo e($additional[0]->panipatti_kar); ?></td>
        <td><?php echo e($additional[0]->panipatti_special_kar); ?></td> 
        <?php
       }else
       {?>
       <td></td>
       <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td> 
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td> 
        
       <?php
       }
        ?>
        
        
        
        
        
        
        <td></td>
        <td></td>
        <td></td>

       
        
    </tr>
    
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <tr>
        <td></td>
        <td></td>
        <td>उत्तर.</td>
        <td><?php echo e($p->north); ?></td>
        <td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td>दक्षिण.</td>
        <td><?php echo e($p->south); ?></td>
        <td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td>पुर्व</td>
        <td><?php echo e($p->east); ?></td>
        <td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td>पच्शिम.</td>
        <td><?php echo e($p->west); ?></td>
        <td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td>व्दार</td>
        <td><?php echo e($p->gate); ?></td>
        <td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td>शौचालय (आहे/नाही)</td>
        <td><?php echo e($p->washroom); ?></td>
        <td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td>नळ (आहे/नाही)</td>
        <td><?php echo e($p->nal); ?></td>
        <td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
    </tr>
</table>
</body>
</html>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\xampp\htdocs\laravel\survey\resources\views/backend/printdetails.blade.php ENDPATH**/ ?>