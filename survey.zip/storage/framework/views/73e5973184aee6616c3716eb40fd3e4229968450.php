
<?php $__env->startSection('index-content'); ?>

				<section role="main" class="content-body">
					<header class="page-header">
						<h2> सर्वेक्षण फॉर्म</h2>
					
						<div class="right-wrapper pull-right">
							<ol class="breadcrumbs">
								<li>
									<a href="/">
										<i class="fa fa-home"></i>
									</a>
								</li>
								<li><span>फॉर्म</span></li>
								<li><span> सर्वेक्षण</span></li>
							</ol>
					
							<a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
						</div>
					</header>
					<!-- start: page -->
					<div class="row">
						<div class="col-md-12">
							<form id="form" action="<?php echo e(route('survey_info.update',$gram_name[0]->id)); ?>" class="form-horizontal" method="post">
							<?php echo csrf_field(); ?>
							<?php echo method_field('PATCH'); ?>
								<section class="panel">
									<header class="panel-heading">
										<div class="panel-actions">
											<a href="#" class="fa fa-caret-down"></a>
											<a href="#" class="fa fa-times"></a>
										</div>

										<h2 class="panel-title"> सर्वेक्षण फॉर्म</h2>
										<!--<p class="panel-subtitle">
											Basic validation will display a label with the error after the form control.
										</p>-->
									</header>
									<div class="panel-body">
									<div class="form-group">
											<label class="col-sm-3 control-label">जिल्हा नाव<span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" value="<?php echo e($jillaselect[0]->area_name); ?>" name="jilla_id" class="form-control" id="jilla_id">
												
											</div>
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">तालुका <span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="taluka_name" class="form-control" id="taluka" value="<?php echo e($talukaselect[0]->area_name); ?>"required> 
												
											</div>
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">ग्रामपंचायत<span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="gram_name" class="form-control" id="gram_id" value="<?php echo e($gramselect[0]->area_name); ?>" required>
												
											</div>
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">स्वयंघोषणापत्र  करुन देणार <span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="self_declaration_name" class="form-control" value="<?php echo e($gram_name[0]->name); ?>"required >
												<?php $__errorArgs = ['self_declaration_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
												<font size="3" color="red"><?php echo e($message); ?></font>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">स्वयंघोषणापत्र  करुन घेणार<span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="self_declaration_gram_name" class="form-control" value="<?php echo e($gram_name[0]->gram_name); ?>" required>
												<?php $__errorArgs = ['self_declaration_gram_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
												<font size="3" color="red"><?php echo e($message); ?></font>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">भोगवटदाराचे नांव<span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="bhogwatdar_name" class="form-control" value="<?php echo e($gram_name[0]->name2); ?>" required>
												<?php $__errorArgs = ['bhogwatdar_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
												<font size="3" color="red"><?php echo e($message); ?></font>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">सिटीसव्‍ह मिळकत धारकाचे नांव<span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="survey_name" class="form-control" value="<?php echo e($gram_name[0]->survey_name); ?>" required>
												<?php $__errorArgs = ['survey_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
												<font size="3" color="red"><?php echo e($message); ?></font>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">मोबाइल नं<span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="mobile_number" class="form-control" value="<?php echo e($gram_name[0]->mbl); ?>" required>
												<?php $__errorArgs = ['mobile_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
												<font size="3" color="red"><?php echo e($message); ?></font>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">आधार नं<span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="adhar_number" class="form-control" value="<?php echo e($gram_name[0]->adhar); ?>" required>
												<?php $__errorArgs = ['adhar_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
												<font size="3" color="red"><?php echo e($message); ?></font>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">पत्नीचे मोबाइल नं <span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="wife_mobile_number" class="form-control" required value="<?php echo e($gram_name[0]->wife_mbl); ?>">
												<?php $__errorArgs = ['wife_mobile_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
												<font size="3" color="red"><?php echo e($message); ?></font>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">पत्नीचे आधार नं<span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="wife_adhar_number" class="form-control" required value="<?php echo e($gram_name[0]->wife_adhar); ?>">
												<?php $__errorArgs = ['wife_adhar_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
												<font size="3" color="red"><?php echo e($message); ?></font>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>	
											</div>
											
										</div>
										<div class="form-group">
										<label class="col-sm-3 control-label">Image<span class="required">*</span></label>
										<div class="col-sm-9">
										<img src="<?php echo e(asset('image')); ?>/<?php echo e($gram_name[0]->img); ?>" height="150px" width="150px" value="<?php echo e($gram_name[0]->img); ?>" name="prvimg">
										</div>
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">Image Uplode<span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="file" name="img" class="form-control">
												<?php $__errorArgs = ['img'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
												<font size="3" color="red"><?php echo e($message); ?></font>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>	
											</div>
											
										</div>
										<div class="form-group">
										<label class="col-sm-3 control-label">Map Image<span class="required">*</span></label>
										<div class="col-sm-9">
										<img src="<?php echo e(asset('image')); ?>/<?php echo e($gram_name[0]->mapimg); ?>" height="150px" width="150px" value="<?php echo e($gram_name[0]->mapimg); ?>" name="premapimg">
										</div>
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">Map Uplode<span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="file" name="mapimg" class="form-control">
												<?php $__errorArgs = ['mapimg'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
												<font size="3" color="red"><?php echo e($message); ?></font>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>	
											</div>
											
										</div>

										<div class="form-group">
											<label class="col-sm-3 control-label">जुना मिळकत क्र<span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="old_tax_number" class="form-control" value="<?php echo e($gram_name[0]->old_tax_no); ?>" required>
												<?php $__errorArgs = ['old_tax_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
												<font size="3" color="red"><?php echo e($message); ?></font>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">सि.सि नं.<span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="s_s_number" class="form-control" value="<?php echo e($gram_name[0]->s_s_no); ?>" required>
												<?php $__errorArgs = ['s_s_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
												<font size="3" color="red"><?php echo e($message); ?></font>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">सि. सि. चैा मि.<span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="s_s_s_m" class="form-control" value="<?php echo e($gram_name[0]->s_s_m); ?>" required>
												<?php $__errorArgs = ['s_s_s_m'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
												<font size="3" color="red"><?php echo e($message); ?></font>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">गट नं.<span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="group_no" class="form-control" value="<?php echo e($gram_name[0]->group_no); ?>" required>
												<?php $__errorArgs = ['group_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
												<font size="3" color="red"><?php echo e($message); ?></font>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">प्लॉट नं.<span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="plot_no" class="form-control" value="<?php echo e($gram_name[0]->plot_no); ?>" required>
												<?php $__errorArgs = ['plot_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
												<font size="3" color="red"><?php echo e($message); ?></font>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>	
											</div>
											
										</div>
										
										<div class="form-group">
											<label class="col-sm-3 control-label">उत्तर / दक्षिण<span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="north_south" class="form-control" value="<?php echo e($gram_name[0]->north_south); ?>" required>
												<?php $__errorArgs = ['north_south'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
												<font size="3" color="red"><?php echo e($message); ?></font>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">पुर्व / पश्चिम <span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="east_west" class="form-control" value="<?php echo e($gram_name[0]->east_west); ?>"required>
												<?php $__errorArgs = ['east_west'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
												<font size="3" color="red"><?php echo e($message); ?></font>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>	
											</div>
											
										</div>
										<table id="t">
  <colgroup>
    <col class="w">
    <col>
    <col>
    <col>
  </colgroup>
  <thead>
    <tr>
											<th>मिळकतीचे वर्णन</th>
											<th>Property Name</th>
											<th>बांधकाम वर्ष</th>
											<th>बांधकाम वय वर्ष</th>
											<th>Floor</th>
											<th>चाै.फुट</th>
											<th>चाै.मि.</th>
											<!-- <th>रेडिरेकनरचे दर</th>
											<th>घसार दर</th>
											<th>भारांक</th> -->
											<th>एकुण कर</th>
										</tr>
  </thead>
  <tbody>
	<?php
	$i=1;
	?>
	<?php $__currentLoopData = $k; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr onclick="myGeeks(this)">
      <td><?php echo $i;?>. <?php echo e($v->varnana_name); ?><input type="hidden" name="varnan<?php echo $i;?>" value="<?php echo e($v->varnana_name); ?>"></td>
	  <td><input type="text" name="property_name<?php echo $i;?>" value="<?php echo e($v->property_name); ?>" id="property_name<?php echo $i;?>" class="property_name">
	  	</td> 
	  <td><input type="text" name="yercon<?php echo $i;?>" class="yercon" id="yercon<?php echo $i;?>" style="width:60px;" value="<?php echo e($v->yercon); ?>"></input></td>
	  <td><input type="text" name="conyerage<?php echo $i;?>" value="<?php echo e($v->conyerage); ?>" id="conyerage<?php echo $i;?>" class="conyerage">
</td> 
	  <td><input type="text" name="floor<?php echo $i;?>" class="floor" id="floor<?php echo $i;?>" style="width:60px;" value="<?php echo e($v->floor); ?>"></input></td>
	  <td><input type="text" name="chf<?php echo $i;?>" class="chf" value="<?php echo e($v->ch_fu); ?>" id="chf<?php echo $i;?>" style="width:60px;"></input></td>
	  <td><input type="text"  name="chm<?php echo $i;?>"class="chm1" value="<?php echo e($v->ch_me); ?>" id="chm<?php echo $i;?>" style="width:60px;"></input></td>
	 <td><input type="text"  name="tol<?php echo $i;?>" id="tol<?php echo $i;?>" value="<?php echo e($v->total); ?>" style="width:60px;"></input></td>
	</tr>
	<?php
	$i++;
	?>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<input type="hidden" value="<?php echo $i;?>" id="rowcount">
    </tr>
	
  </tbody>
</table>
								<div class="form-group">
											<label class="col-sm-3 control-label">Total Sq.ft <span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="total_sqft" class="form-control" value="<?php echo e($gram_name[0]->total_sqft); ?>">
												<?php $__errorArgs = ['total_sqft'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
												<font size="3" color="red"><?php echo e($message); ?></font>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>	
											</div>
											
										</div>
								<div class="form-group">
											<label class="col-sm-3 control-label">नळ कनेक्शन <span class="required">*</span></label>
											<div class="col-sm-9">
												<select name="nalcon" class="form-control" >
													<option value="<?php echo e($gram_name[0]->nal); ?>"><?php echo e($gram_name[0]->nal); ?></option>
													
												</select>
												<?php $__errorArgs = ['nalcon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
												<font size="3" color="red"><?php echo e($message); ?></font>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label"> शाैचालय <span class="required">*</span></label>
											<div class="col-sm-9">
											<select name="washroom" class="form-control" >
											<option value="<?php echo e($gram_name[0]->washroom); ?>"><?php echo e($gram_name[0]->washroom); ?></option>
													
													
												</select>
												<?php $__errorArgs = ['washroom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
												<font size="3" color="red"><?php echo e($message); ?></font>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">उत्तर <span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="north" class="form-control" value="<?php echo e($gram_name[0]->north); ?>" required>
												<?php $__errorArgs = ['north'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
												<font size="3" color="red"><?php echo e($message); ?></font>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">दक्षिण <span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="south" class="form-control" value="<?php echo e($gram_name[0]->south); ?>" required>
												<?php $__errorArgs = ['south'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
												<font size="3" color="red"><?php echo e($message); ?></font>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">पूर्व <span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="east" class="form-control" value="<?php echo e($gram_name[0]->east); ?>"required>
												<?php $__errorArgs = ['east'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
												<font size="3" color="red"><?php echo e($message); ?></font>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">पश्चिम <span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="west" class="form-control" value="<?php echo e($gram_name[0]->west); ?>"required>
												<?php $__errorArgs = ['west'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
												<font size="3" color="red"><?php echo e($message); ?></font>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">व्दार <span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="gate" class="form-control" value="<?php echo e($gram_name[0]->gate); ?>"required>
												<?php $__errorArgs = ['gate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
												<font size="3" color="red"><?php echo e($message); ?></font>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>	
											</div>
											
										</div>
										<br><br>
									</div>
																</section>
							</form>
						</div>
						
					</div>
					<!-- end: page -->
				</section>
			<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\sl\resources\views/backend/survey_show.blade.php ENDPATH**/ ?>