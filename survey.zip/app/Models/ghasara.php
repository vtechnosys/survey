<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ghasara extends Model
{
    use HasFactory;
    protected $fillable=['jilla','taluka','gram','types','one','two','three','four','five','six','seven','eight','greater_than_sixty'];
}
