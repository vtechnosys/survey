<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class readyreknal extends Model
{
    use HasFactory;
    protected $fillable=['jilla','taluka','gram','types','rate'];
}
