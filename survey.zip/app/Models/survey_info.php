<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class survey_info extends Model
{
    use HasFactory;
	protected $fillable=['area_id','name','jilla_id','taluka_id','gram_id','gram_name','name2','survey_name','mbl','adhar','old_tax_no','s_s_no','s_s_m','group_no','plot_no','total_sqft','north_south','east_west','details','north','south','east','west','gate','wife_mbl','wife_adhar','img','mapimg','nal','washroom','status','tax_number','date'];
}
