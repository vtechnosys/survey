<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\varnan;

class VernanController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $login=$request->session()->get('uname');
        if($login==null)
        {
            return redirect('/');
        }
        else
        {
        $varnan=varnan::get();
        return view('backend.varnan_view',compact('varnan'));
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        $login=$request->session()->get('uname');
        if($login==null)
        {
            return redirect('/');
        }
        else
        {
        $varnan=varnan::get();
        return view('backend.varnan',compact('varnan'));
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $name=$request->get('मिळकतीचे_वर्णन_नाव');
        
        $data=new varnan([
            'name'=>$name,
            'status'=>'active'
        ]);
        $data->save();
        return redirect('/varnan/create');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $varnan=varnan::find($id);
        return view('backend.varnan_show',compact('varnan'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $varnan=varnan::find($id);
        return view('backend.varnan_edit',compact('varnan'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $varnan=varnan::find($id);
        $varnan->name=$request->get('मिळकतीचे_वर्णन_नाव');
        $varnan->update();
        return redirect('/varnan/create');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $data=varnan::find($id);
        $data->delete();
        return redirect('/varnan');
    }
    public function statuschkvarnan($id)
    {
        $varnan=varnan::find($id);
        $s=$varnan->status;
        if($s=='active')
        {
            $varnan=varnan::find($id);
            $varnan->status='inactive';
            $varnan->update();
            return redirect('/varnan/create');
        }
        else if($s=='inactive')
        {
            $varnan=varnan::find($id);
            $varnan->status='active';
            $varnan->update();
            return redirect('/varnan/create');
        }
    }
}
