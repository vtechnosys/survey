<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\survey_info;
use App\Models\area_master;
use App\Models\varnan;
use DB;
class Survey_infoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
		$login=$request->session()->get('uname');
        if($login==null)
        {
            return redirect('/');
        }
        else
        {
		$survey_i=DB::table('area_masters')
		
					->join('survey_infos','survey_infos.taluka_id','=','area_masters.id')
					->select('*','area_masters.id as aid')
					->get();
		
		$jilla_i=DB::table('area_masters')
					->join('survey_infos','survey_infos.jilla_id','=','area_masters.id')
					->select('*','area_masters.id as aid')
					->get();
		$gram_i=DB::table('area_masters')
					->join('survey_infos','survey_infos.gram_id','=','area_masters.id')
					->select('*','area_masters.id as aid')
					->get();
		$jillanamesss=array();
		foreach($survey_i as $d)
			{
				$jillaaname=DB::table('area_masters')
							->where('id','=',$d->jilla_id)
							->get();
				$tname=$jillaaname[0]->area_name;
				array_push($jillanamesss,$tname);
				//echo $areanamesss;
			}
		
		$areanamesss=array();
		foreach($survey_i as $d)
		{
			$talukaname=DB::table('area_masters')
					->where('id','=',$d->taluka_id)
					->get();
			$tname=$talukaname[0]->area_name;
			array_push($areanamesss,$tname);
			//echo $areanamesss;
		}
		
		$gramnamesss=array();
		foreach($survey_i as $d)
		{
			$gramname=DB::table('area_masters')
							->where('id','=',$d->gram_id)
							->get();
			$tname=$gramname[0]->area_name;
			array_push($gramnamesss,$tname);
			//echo $areanamesss;
		}
		
		//echo $gramid;
		//exit();
		$demo="";
		
		foreach($survey_i as $k)
		{
			$sur=$k->details;
			//echo $sur;
			$decode=json_decode($sur);
			//var_dump($decode);
			$demo=$decode;
			
		
		}
		
		//var_dump($demo);
		//exit();
		$jilla=DB::table('area_masters')
					->where('parent_id','=','0')
					->where('super_id','=','0')
					->where('status','=','active')
					->get();
		$taluka=DB::table('area_masters')
					->where('parent_id','!=','0')
					->where('super_id','=','0')
					->where('status','=','active')
					->get();
		$gram=DB::table('area_masters')
					->where('parent_id','!=','0')
					->where('super_id','!=','0')
					->where('status','=','active')
					->get();
		$jillaselect=DB::table('area_masters')
					->join('survey_infos','survey_infos.jilla_id','=','area_masters.id')
					->select('*','area_masters.id as aid')
					->get();
		$talukaselect=DB::table('area_masters')
					->join('survey_infos','survey_infos.taluka_id','=','area_masters.id')
					->select('*','area_masters.id as aid')
					->get();
		$gramselect=DB::table('area_masters')
					->join('survey_infos','survey_infos.gram_id','=','area_masters.id')
					->select('*','area_masters.id as aid')
					->get();
		return view('backend.survey_view',compact('survey_i','demo','jilla','taluka','gram','jillaselect','talukaselect','gramselect','areanamesss','jillanamesss','gramnamesss'));
	}
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
		$login=$request->session()->get('uname');
        if($login==null)
        {
            return redirect('/');
        }
        else
        {
        
		$jilla=DB::table('area_masters')
					->where('parent_id','=','0')
					->where('super_id','=','0')
					->get();
		/*$taluka=DB::table('area_masters')
					->where('parent_id','=','0')
					->get();*/
		$varanan=DB::table('varnans')
					->where('status','=','active')
					->get();
		return view('backend.survey_info',compact('jilla','varanan'));
		}
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
	public function getgram(Request $request,$name)
	{
		$gram_name=DB::table('area_masters')
					->where('parent_id','=',$name)
					->get();
		$resp = "";
		foreach($gram_name as $gm)
		{
			$resp .="".$gm->id."_".$gm->area_name;
			$resp .="-";
			
		}
		echo $resp;
	}
    public function store(Request $request)
    {
        $varanan=DB::table('varnans')
					->where('status','=','active')
					->count();
		$demo=array();
		for($i=1; $i<=1; $i++)
		{
			for($j=$i; $j<=$varanan; $j++)
			{
				$data=array(
				"varnana_name"=>$request->get('varnan'.$j),
				"property_name"=>$request->get('property_name'.$j),
				"yercon"=>$request->get('yercon'.$j),
				"conyerage"=>$request->get('conyerage'.$j),
				"floor"=>$request->get('floor'.$j),
				"ch_fu"=>$request->get('chf'.$j),
				"ch_me"=>$request->get('chm'.$j),
				"total"=>$request->get('tol'.$j)
				);
				array_push($demo,$data);
			}
		}
		//$filesmap = $request->file('mapimg');
		//$file_name2 = $filesmap->getClientOriginalName();
		$d=json_encode($demo);
		$mimg=$request->hasFile('img');
		$mapimg=$request->hasFile('mapimg');
	//	echo $mimg;
		//echo $mapimg;
	//	exit();
	    $survey_name=$request->get('survey_name');
	    $wife_mbl=$request->get('wife_mobile_number');
	    $old_tax=$request->get('old_tax_number');
	    $ssn=$request->get('s_s_number');
	    $sschm=$request->get('s_s_s_m');
	    $gat_no=$request->get('group_no');
	    $plot_no=$request->get('plot_no');
	    $gate=$request->get('gate');
	   
    		if($mimg==1 && $mapimg==1 && $survey_name=="" && $wife_mbl=="" && $old_tax=="" && $ssn=="" && $sschm=="" && $gat_no=="" && $plot_no=="" && $gate=="")
    		{
    			$files = $request->file('img');
    			$file_name1 = $files->getClientOriginalName();
    			$mapfiles = $request->file('mapimg');
    			$file_name2 = $mapfiles->getClientOriginalName();
    			$survey_info=new survey_info([
    			'jilla_id'=>$request->get('jilla_id'),
    			'taluka_id'=>$request->get('taluka_name'),
    			'gram_id'=>$request->get('gram_name'),
    			'name'=>$request->get('self_declaration_name'),
    			'gram_name'=>$request->get('self_declaration_gram_name'),
    			'name2'=>$request->get('bhogwatdar_name'),
    			'survey_name'=>'null',
    			'mbl'=>$request->get('mobile_number'),
    			'adhar'=>$request->get('adhar_number'),
    			'old_tax_no'=>'null',
    			's_s_no'=>'null',
    			's_s_m'=>'null',
    			'group_no'=>'null',
    			'plot_no'=>'null',
    			'total_sqft'=>$request->get('tolsqft'),
    			'north_south'=>$request->get('north_south'),
    			'east_west'=>$request->get('east_west'),
    			'details'=>$d,
    			'north'=>$request->get('north'),
    			'south'=>$request->get('south'),
    			'east'=>$request->get('east'),
    			'west'=>$request->get('west'),
    			'gate'=>'null',
    			'wife_mbl'=>'null',
    			'wife_adhar'=>$request->get('wife_adhar_number'),
    			'img'=>$file_name1,
    			'mapimg'=>$file_name2,
    			'nal'=>$request->get('nalcon'),
    			'washroom'=>$request->get('washroom'),
    			'tax_number'=>$request->get('tax_number'),
    			'status'=>'active'
    			]);
    			$survey_info->save();
    		   $files->move('image/',$file_name1);
    		   $mapfiles->move('image/',$file_name2);
    		    //exit();
    			return redirect('/survey_info');
    		}else if($request->hasFile('img') && $survey_name=="" && $wife_mbl=="" && $old_tax=="" && $ssn=="" && $sschm=="" && $gat_no=="" && $plot_no=="" && $gate=="")
    		{
    			$files = $request->file('img');
    			$file_name1 = $files->getClientOriginalName();
    			$survey_info=new survey_info([
    			'jilla_id'=>$request->get('jilla_id'),
    			'taluka_id'=>$request->get('taluka_name'),
    			'gram_id'=>$request->get('gram_name'),
    			'name'=>$request->get('self_declaration_name'),
    			'gram_name'=>$request->get('self_declaration_gram_name'),
    			'name2'=>$request->get('bhogwatdar_name'),
    			'survey_name'=>'null',
    			'mbl'=>$request->get('mobile_number'),
    			'adhar'=>$request->get('adhar_number'),
    			'old_tax_no'=>'null',
    			's_s_no'=>'null',
    			's_s_m'=>'null',
    			'group_no'=>'null',
    			'plot_no'=>'null',
    			'total_sqft'=>$request->get('tolsqft'),
    			'north_south'=>$request->get('north_south'),
    			'east_west'=>$request->get('east_west'),
    			'details'=>$d,
    			'north'=>$request->get('north'),
    			'south'=>$request->get('south'),
    			'east'=>$request->get('east'),
    			'west'=>$request->get('west'),
    			'gate'=>'null',
    			'wife_mbl'=>'null',
    			'wife_adhar'=>$request->get('wife_adhar_number'),
    			'img'=>$file_name1,
    			'mapimg'=>'null',
    			'nal'=>$request->get('nalcon'),
    			'washroom'=>$request->get('washroom'),
    			'tax_number'=>$request->get('tax_number'),
    			'status'=>'active'
    			]);
    			$survey_info->save();
    			$files->move('image/',$file_name1);
    			return redirect('/survey_info');
    		}else if($request->hasFile('mapimg') && $survey_name=="" && $wife_mbl=="" && $old_tax=="" && $ssn=="" && $sschm=="" && $gat_no=="" && $plot_no=="" && $gate=="")
    		{
    			$files = $request->file('mapimg');
    			$file_name1 = $files->getClientOriginalName();
    			$survey_info=new survey_info([
    			'jilla_id'=>$request->get('jilla_id'),
    			'taluka_id'=>$request->get('taluka_name'),
    			'gram_id'=>$request->get('gram_name'),
    			'name'=>$request->get('self_declaration_name'),
    			'gram_name'=>$request->get('self_declaration_gram_name'),
    			'name2'=>$request->get('bhogwatdar_name'),
    			'survey_name'=>'null',
    			'mbl'=>$request->get('mobile_number'),
    			'adhar'=>$request->get('adhar_number'),
    		    'old_tax_no'=>'null',
    			's_s_no'=>'null',
    			's_s_m'=>'null',
    			'group_no'=>'null',
    			'plot_no'=>'null',
    			'total_sqft'=>$request->get('tolsqft'),
    			'north_south'=>$request->get('north_south'),
    			'east_west'=>$request->get('east_west'),
    			'details'=>$d,
    			'north'=>$request->get('north'),
    			'south'=>$request->get('south'),
    			'east'=>$request->get('east'),
    			'west'=>$request->get('west'),
    			'gate'=>'null',
    			'wife_mbl'=>'null',
    			'wife_adhar'=>$request->get('wife_adhar_number'),
    			'img'=>'null',
    			'mapimg'=>$file_name1,
    			'nal'=>$request->get('nalcon'),
    			'washroom'=>$request->get('washroom'),
    			'tax_number'=>$request->get('tax_number'),
    			'status'=>'active'
    			]);
    			$survey_info->save();
    	        $files->move('image/',$file_name1);
    			return redirect('/survey_info');
    		} 
    		else
    		{
    			$survey_info=new survey_info([
    				'jilla_id'=>$request->get('jilla_id'),
    				'taluka_id'=>$request->get('taluka_name'),
    				'gram_id'=>$request->get('gram_name'),
    				'name'=>$request->get('self_declaration_name'),
    				'gram_name'=>$request->get('self_declaration_gram_name'),
    				'name2'=>$request->get('bhogwatdar_name'),
    				'survey_name'=>'null',
    				'mbl'=>$request->get('mobile_number'),
    				'adhar'=>$request->get('adhar_number'),
        			'old_tax_no'=>'null',
        			's_s_no'=>'null',
        			's_s_m'=>'null',
        			'group_no'=>'null',
        			'plot_no'=>'null',
    				'total_sqft'=>$request->get('tolsqft'),
    				'north_south'=>$request->get('north_south'),
    				'east_west'=>$request->get('east_west'),
    				'details'=>$d,
    				'north'=>$request->get('north'),
    				'south'=>$request->get('south'),
    				'east'=>$request->get('east'),
    				'west'=>$request->get('west'),
    				'gate'=>'null',
    				'wife_mbl'=>'null',
    				'wife_adhar'=>$request->get('wife_adhar_number'),
    				'img'=>'null',
    				'mapimg'=>'null',
    				'nal'=>$request->get('nalcon'),
    				'washroom'=>$request->get('washroom'),
    				'tax_number'=>$request->get('tax_number'),
    				'status'=>'active'
    				]);
    			$survey_info->save();
    			return redirect('/survey_info');
    		}
	        if($mimg==1 && $mapimg==1 && $survey_name!="" && $wife_mbl!="" && $old_tax!="" && $ssn!="" && $sschm!="" && $gat_no!="" && $plot_no!="" && $gate!="")
    		{
    			$files = $request->file('img');
    			$file_name1 = $files->getClientOriginalName();
    			$mapfiles = $request->file('mapimg');
    			$file_name2 = $mapfiles->getClientOriginalName();
    			$survey_info=new survey_info([
    			'jilla_id'=>$request->get('jilla_id'),
    			'taluka_id'=>$request->get('taluka_name'),
    			'gram_id'=>$request->get('gram_name'),
    			'name'=>$request->get('self_declaration_name'),
    			'gram_name'=>$request->get('self_declaration_gram_name'),
    			'name2'=>$request->get('bhogwatdar_name'),
    			'survey_name'=>$survey_name,
    			'mbl'=>$request->get('mobile_number'),
    			'adhar'=>$request->get('adhar_number'),
    			'old_tax_no'=>$old_tax,
    			's_s_no'=>$ssn,
    			's_s_m'=>$sschm,
    			'group_no'=>$gat_no,
    			'plot_no'=>$plot_no,
    			'total_sqft'=>$request->get('tolsqft'),
    			'north_south'=>$request->get('north_south'),
    			'east_west'=>$request->get('east_west'),
    			'details'=>$d,
    			'north'=>$request->get('north'),
    			'south'=>$request->get('south'),
    			'east'=>$request->get('east'),
    			'west'=>$request->get('west'),
    			'gate'=>$gate,
    			'wife_mbl'=>$wife_mbl,
    			'wife_adhar'=>$request->get('wife_adhar_number'),
    			'img'=>$file_name1,
    			'mapimg'=>$file_name2,
    			'nal'=>$request->get('nalcon'),
    			'washroom'=>$request->get('washroom'),
    			'tax_number'=>$request->get('tax_number'),
    			'status'=>'active'
    			]);
    			$survey_info->save();
    		   $files->move('image/',$file_name1);
    		   $mapfiles->move('image/',$file_name2);
    		    //exit();
    			return redirect('/survey_info');
    		}else if($request->hasFile('img') && $wife_mbl!="" && $old_tax!="" && $ssn!="" && $sschm!="" && $gat_no!="" && $plot_no!="" && $gate!="")
    		{
    			$files = $request->file('img');
    			$file_name1 = $files->getClientOriginalName();
    			$survey_info=new survey_info([
    			'jilla_id'=>$request->get('jilla_id'),
    			'taluka_id'=>$request->get('taluka_name'),
    			'gram_id'=>$request->get('gram_name'),
    			'name'=>$request->get('self_declaration_name'),
    			'gram_name'=>$request->get('self_declaration_gram_name'),
    			'name2'=>$request->get('bhogwatdar_name'),
    			'survey_name'=>$survey_name,
    			'mbl'=>$request->get('mobile_number'),
    			'adhar'=>$request->get('adhar_number'),
    			'old_tax_no'=>$old_tax,
    			's_s_no'=>$ssn,
    			's_s_m'=>$sschm,
    			'group_no'=>$gat_no,
    			'plot_no'=>$plot_no,
    			'total_sqft'=>$request->get('tolsqft'),
    			'north_south'=>$request->get('north_south'),
    			'east_west'=>$request->get('east_west'),
    			'details'=>$d,
    			'north'=>$request->get('north'),
    			'south'=>$request->get('south'),
    			'east'=>$request->get('east'),
    			'west'=>$request->get('west'),
    			'gate'=>$gate,
    			'wife_mbl'=>$wife_mbl,
    			'wife_adhar'=>$request->get('wife_adhar_number'),
    			'img'=>$file_name1,
    			'mapimg'=>'null',
    			'nal'=>$request->get('nalcon'),
    			'washroom'=>$request->get('washroom'),
    			'tax_number'=>$request->get('tax_number'),
    			'status'=>'active'
    			]);
    			$survey_info->save();
    			$files->move('image/',$file_name1);
    			return redirect('/survey_info');
    		}else if($request->hasFile('mapimg')&& $wife_mbl!="" && $old_tax!="" && $ssn!="" && $sschm!="" && $gat_no!="" && $plot_no!="" && $gate!="")
    		{
    			$files = $request->file('mapimg');
    			$file_name1 = $files->getClientOriginalName();
    			$survey_info=new survey_info([
    			'jilla_id'=>$request->get('jilla_id'),
    			'taluka_id'=>$request->get('taluka_name'),
    			'gram_id'=>$request->get('gram_name'),
    			'name'=>$request->get('self_declaration_name'),
    			'gram_name'=>$request->get('self_declaration_gram_name'),
    			'name2'=>$request->get('bhogwatdar_name'),
    			'survey_name'=>$survey_name,
    			'mbl'=>$request->get('mobile_number'),
    			'adhar'=>$request->get('adhar_number'),
    		    'old_tax_no'=>$old_tax,
    			's_s_no'=>$ssn,
    			's_s_m'=>$sschm,
    			'group_no'=>$gat_no,
    			'plot_no'=>$plot_no,
    			'total_sqft'=>$request->get('tolsqft'),
    			'north_south'=>$request->get('north_south'),
    			'east_west'=>$request->get('east_west'),
    			'details'=>$d,
    			'north'=>$request->get('north'),
    			'south'=>$request->get('south'),
    			'east'=>$request->get('east'),
    			'west'=>$request->get('west'),
    			'gate'=>$gate,
    			'wife_mbl'=>$wife_mbl,
    			'wife_adhar'=>$request->get('wife_adhar_number'),
    			'img'=>'null',
    			'mapimg'=>$file_name1,
    			'nal'=>$request->get('nalcon'),
    			'washroom'=>$request->get('washroom'),
    			'tax_number'=>$request->get('tax_number'),
    			'status'=>'active'
    			]);
    			$survey_info->save();
    	        $files->move('image/',$file_name1);
    			return redirect('/survey_info');
    		} 
    		else
    		{
    			$survey_info=new survey_info([
    				'jilla_id'=>$request->get('jilla_id'),
    				'taluka_id'=>$request->get('taluka_name'),
    				'gram_id'=>$request->get('gram_name'),
    				'name'=>$request->get('self_declaration_name'),
    				'gram_name'=>$request->get('self_declaration_gram_name'),
    				'name2'=>$request->get('bhogwatdar_name'),
    				'survey_name'=>$survey_name,
    				'mbl'=>$request->get('mobile_number'),
    				'adhar'=>$request->get('adhar_number'),
        			'old_tax_no'=>$old_tax,
        			's_s_no'=>$ssn,
        			's_s_m'=>$sschm,
        			'group_no'=>$gat_no,
        			'plot_no'=>$plot_no,
    				'total_sqft'=>$request->get('tolsqft'),
    				'north_south'=>$request->get('north_south'),
    				'east_west'=>$request->get('east_west'),
    				'details'=>$d,
    				'north'=>$request->get('north'),
    				'south'=>$request->get('south'),
    				'east'=>$request->get('east'),
    				'west'=>$request->get('west'),
    				'gate'=>$gate,
    				'wife_mbl'=>$wife_mbl,
    				'wife_adhar'=>$request->get('wife_adhar_number'),
    				'img'=>'null',
    				'mapimg'=>'null',
    				'nal'=>$request->get('nalcon'),
    				'washroom'=>$request->get('washroom'),
    				'tax_number'=>$request->get('tax_number'),
    				'status'=>'active'
    				]);
    			$survey_info->save();
    			return redirect('/survey_info');
    		}
	    
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
		$gram_name=DB::table('area_masters')
					->join('survey_infos','survey_infos.taluka_id','=','area_masters.id')
					->where('survey_infos.id','=',$id)
					->select('*','area_masters.id as aid')
					->get();
		$jilla=DB::table('area_masters')
					->where('parent_id','=','0')
					->where('super_id','=','0')
					->get();
		$taluka=DB::table('area_masters')
					->where('parent_id','!=','0')
					->where('super_id','=','0')
					->get();
		$survey_i=DB::table('area_masters')
					->join('survey_infos','survey_infos.taluka_id','=','area_masters.id')
					->where('survey_infos.id','=',$id)
					->select('*','area_masters.id as aid')
					->get();
		$data="";
		foreach($survey_i as $r)
		{
			$data=$r->details;
		}
		$k=json_decode($data);
		$jillaselect=DB::table('area_masters')
						->join('survey_infos','survey_infos.jilla_id','=','area_masters.id')
						->select('*','area_masters.id as aid')
						->where('survey_infos.id','=',$id)
						->get();
		$talukaselect=DB::table('area_masters')
						->join('survey_infos','survey_infos.taluka_id','=','area_masters.id')
						->select('*','area_masters.id as aid')
						->where('survey_infos.id','=',$id)
						->get();
		$gramselect=DB::table('area_masters')
						->join('survey_infos','survey_infos.gram_id','=','area_masters.id')
						->select('*','area_masters.id as aid')
						->where('survey_infos.id','=',$id)
						->get();
        // $survey_i=DB::table('area_masters')
		// 			->join('survey_infos','survey_infos.taluka_id','=','area_masters.id')
		// 			->where('survey_infos.id','=',$id)
		// 			->select('*','area_masters.id as aid')
		// 			->get();
		// $data="";
		// foreach($survey_i as $r)
		// {
		// 	$data=$r->details;
		// }
		// $k=json_decode($data);
		// //var_dump($k);
		// //exit();
		// $varnan=varnan::get();
		return view('backend.survey_show',compact('taluka','gram_name','jilla','k','jillaselect','talukaselect','gramselect'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
		
        $gram_name=DB::table('area_masters')
					->join('survey_infos','survey_infos.taluka_id','=','area_masters.id')
					->where('survey_infos.id','=',$id)
					->select('*','area_masters.id as aid')
					->get();
		$jilla=DB::table('area_masters')
					->where('parent_id','=','0')
					->where('super_id','=','0')
					->get();
		$taluka=DB::table('area_masters')
					->where('parent_id','!=','0')
					->where('super_id','=','0')
					->get();
		$survey_i=DB::table('area_masters')
					->join('survey_infos','survey_infos.taluka_id','=','area_masters.id')
					->where('survey_infos.id','=',$id)
					->select('*','area_masters.id as aid')
					->get();
		$data="";
		foreach($survey_i as $r)
		{
			$data=$r->details;
		}
		$v=json_decode($data);
		$jillaselect=DB::table('area_masters')
						->join('survey_infos','survey_infos.jilla_id','=','area_masters.id')
						->select('*','area_masters.id as aid')
						->where('survey_infos.id','=',$id)
						->get();
		$talukaselect=DB::table('area_masters')
						->join('survey_infos','survey_infos.taluka_id','=','area_masters.id')
						->select('*','area_masters.id as aid')
						->where('survey_infos.id','=',$id)
						->get();
		$gramselect=DB::table('area_masters')
						->join('survey_infos','survey_infos.gram_id','=','area_masters.id')
						->select('*','area_masters.id as aid')
						->where('survey_infos.id','=',$id)
						->get();
		//var_dump($gramselect);
		//exit();
		// $users = DB::table('area_masters as A')
        //    ->join('area_masters as B', 'A.id', '=', 'B.parent_id')
        //    ->select('A.area_name AS jilla', 'B.area_name AS taluka','B.id as tid','B.status as tstatus')
		//    ->where('B.super_id','=','0')
        //    ->get();
        
        $varanan=DB::table('varnans')
					->where('status','=','active')
					->get();
		return view('backend.survey_edit',compact('taluka','gram_name','jilla','v','jillaselect','talukaselect','gramselect','varanan'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
       
		$varanan=DB::table('varnans')
					->where('status','=','active')
					->count();
		$demo=array();
		for($i=1; $i<=1; $i++)
		{
			for($j=$i; $j<=$varanan; $j++)
			{
				$data=array(
					"varnana_name"=>$request->get('varnan'.$j),
					"property_name"=>$request->get('property_name'.$j),
					"yercon"=>$request->get('yercon'.$j),
					"conyerage"=>$request->get('conyerage'.$j),
					"floor"=>$request->get('floor'.$j),
					"ch_fu"=>$request->get('chf'.$j),
					"ch_me"=>$request->get('chm'.$j),
					"total"=>$request->get('tol'.$j)
				);
				array_push($demo,$data);
			}
		}
		$d=json_encode($demo);
		$mimg=$request->hasFile('img');
		$mapimg=$request->hasFile('mapimg');
		//echo $mimg;
		//echo $mapimg;
		//exit();
		if($mimg=="" && $mapimg=="")
		{
			
			$survey_info=survey_info::find($id);
			$survey_info->jilla_id=$request->get('jilla_id');
			$survey_info->taluka_id=$request->get('taluka_name');
			$survey_info->gram_id=$request->get('gram_name');
			$survey_info->name=$request->get('self_declaration_name');
			$survey_info->gram_name=$request->get('self_declaration_gram_name');
			$survey_info->name2=$request->get('bhogwatdar_name');
			$survey_info->survey_name=$request->get('survey_name');
			$survey_info->mbl=$request->get('mobile_number');
			$survey_info->wife_mbl=$request->get('wife_mobile_number');
			$survey_info->wife_adhar=$request->get('wife_adhar_number');
			$survey_info->adhar=$request->get('adhar_number');
			$survey_info->old_tax_no=$request->get('old_tax_number');
			$survey_info->s_s_no=$request->get('s_s_number');
			$survey_info->s_s_m=$request->get('s_s_s_m');
			$survey_info->group_no=$request->get('group_no');
			$survey_info->plot_no=$request->get('plot_no');
			$survey_info->total_sqft=$request->get('total_sqft');
			$survey_info->north_south=$request->get('north_south');
			$survey_info->east_west=$request->get('east_west');
			$survey_info->details=$d;
			$survey_info->north=$request->get('north');
			$survey_info->nal=$request->get('nalcon');
			$survey_info->washroom=$request->get('washroom');

			$survey_info->south=$request->get('south');
			$survey_info->east=$request->get('east');
			$survey_info->west=$request->get('west');
			$survey_info->gate=$request->get('gate');
			
			$survey_info->update();
			return redirect('/survey_info');
		} else if($mimg==1 && $mapimg==1)
		{
			$files = $request->file('img');
			$file_name1 = $files->getClientOriginalName();
			$mapfiles = $request->file('mapimg');
			$file_name2 = $mapfiles->getClientOriginalName();
			$survey_info=survey_info::find($id);
			$survey_info->jilla_id=$request->get('jilla_id');
			$survey_info->taluka_id=$request->get('taluka_name');
			$survey_info->gram_id=$request->get('gram_name');
			$survey_info->name=$request->get('self_declaration_name');
			$survey_info->gram_name=$request->get('self_declaration_gram_name');
			$survey_info->name2=$request->get('bhogwatdar_name');
			$survey_info->survey_name=$request->get('survey_name');
			$survey_info->mbl=$request->get('mobile_number');
			$survey_info->wife_mbl=$request->get('wife_mobile_number');
			$survey_info->wife_adhar=$request->get('wife_adhar_number');
			$survey_info->adhar=$request->get('adhar_number');
			$survey_info->img=$file_name1;
			$survey_info->mapimg=$file_name2;
			$survey_info->old_tax_no=$request->get('old_tax_number');
			$survey_info->s_s_no=$request->get('s_s_number');
			$survey_info->s_s_m=$request->get('s_s_s_m');
			$survey_info->group_no=$request->get('group_no');
			$survey_info->plot_no=$request->get('plot_no');
			$survey_info->total_sqft=$request->get('total_sqft');
			$survey_info->north_south=$request->get('north_south');
			$survey_info->east_west=$request->get('east_west');
			$survey_info->details=$d;
			$survey_info->north=$request->get('north');
			$survey_info->nal=$request->get('nalcon');
			$survey_info->washroom=$request->get('washroom');

			$survey_info->south=$request->get('south');
			$survey_info->east=$request->get('east');
			$survey_info->west=$request->get('west');
			$survey_info->gate=$request->get('gate');
			$files->move('image/',$file_name1);
			$mapfiles->move('image/',$file_name2);
			$survey_info->update();
		
			return redirect('/survey_info');
			
		} else if($mimg==1)
		{
			$files = $request->file('img');
			$file_name1 = $files->getClientOriginalName();
			$survey_info=survey_info::find($id);
			$survey_info->jilla_id=$request->get('jilla_id');
			$survey_info->taluka_id=$request->get('taluka_name');
			$survey_info->gram_id=$request->get('gram_name');
			$survey_info->name=$request->get('self_declaration_name');
			$survey_info->gram_name=$request->get('self_declaration_gram_name');
			$survey_info->name2=$request->get('bhogwatdar_name');
			$survey_info->survey_name=$request->get('survey_name');
			$survey_info->mbl=$request->get('mobile_number');
			$survey_info->wife_mbl=$request->get('wife_mobile_number');
			$survey_info->wife_adhar=$request->get('wife_adhar_number');
			$survey_info->adhar=$request->get('adhar_number');
			$survey_info->img=$file_name1;
			$survey_info->old_tax_no=$request->get('old_tax_number');
			$survey_info->s_s_no=$request->get('s_s_number');
			$survey_info->s_s_m=$request->get('s_s_s_m');
			$survey_info->group_no=$request->get('group_no');
			$survey_info->total_sqft=$request->get('total_sqft');
			$survey_info->yr_const=$request->get('yearcon');
			$survey_info->north_south=$request->get('north_south');
			$survey_info->east_west=$request->get('east_west');
			$survey_info->details=$d;
			$survey_info->north=$request->get('north');
			$survey_info->nal=$request->get('nalcon');
			$survey_info->washroom=$request->get('washroom');

			$survey_info->south=$request->get('south');
			$survey_info->east=$request->get('east');
			$survey_info->west=$request->get('west');
			$survey_info->gate=$request->get('gate');
				$files->move('image/',$file_name1);
			$survey_info->update();
		
			return redirect('/survey_info');
		} else if($mapimg==1)
		{
			$mapfiles = $request->file('mapimg');
			$file_name2 = $mapfiles->getClientOriginalName();
			$survey_info=survey_info::find($id);
			$survey_info->jilla_id=$request->get('jilla_id');
			$survey_info->taluka_id=$request->get('taluka_name');
			$survey_info->gram_id=$request->get('gram_name');
			$survey_info->name=$request->get('self_declaration_name');
			$survey_info->gram_name=$request->get('self_declaration_gram_name');
			$survey_info->name2=$request->get('bhogwatdar_name');
			$survey_info->survey_name=$request->get('survey_name');
			$survey_info->mbl=$request->get('mobile_number');
			$survey_info->wife_mbl=$request->get('wife_mobile_number');
			$survey_info->wife_adhar=$request->get('wife_adhar_number');
			$survey_info->adhar=$request->get('adhar_number');
			$survey_info->mapimg=$file_name2;
			$survey_info->old_tax_no=$request->get('old_tax_number');
			$survey_info->s_s_no=$request->get('s_s_number');
			$survey_info->s_s_m=$request->get('s_s_s_m');
			$survey_info->group_no=$request->get('group_no');
			$survey_info->plot_no=$request->get('plot_no');
			$survey_info->total_sqft=$request->get('total_sqft');
			$survey_info->north_south=$request->get('north_south');
			$survey_info->east_west=$request->get('east_west');
			$survey_info->details=$d;
			$survey_info->north=$request->get('north');
			$survey_info->nal=$request->get('nalcon');
			$survey_info->washroom=$request->get('washroom');

			$survey_info->south=$request->get('south');
			$survey_info->east=$request->get('east');
			$survey_info->west=$request->get('west');
			$survey_info->gate=$request->get('gate');
				$mapfiles->move('image/',$file_name2);
			$survey_info->update();
		
			return redirect('/survey_info');
		}
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $sur_del=survey_info::find($id);
		$sur_del->delete();
		return redirect('/survey_info');
    }
	public function apistore(Request $request)
	{
		$demo=array();
		$arr=array();
		for($i=1; $i<=1; $i++)
		{
			for($j=$i; $j<=8; $j++)
			{
				$data=array(
				"ch_fu"=>$request->get('chf'.$j),
				"ch_me"=>$request->get('chm'.$j),
				"ready"=>$request->get('red'.$j),
				"gasar"=>$request->get('gas'.$j),
				"bharank"=>$request->get('bhk'.$j),
				"total"=>$request->get('tol'.$j)
				);
				array_push($demo,$data);
				
				//$decode=json_decode($d);
				//print_r($decode);
			}
		}
		$d=json_encode($demo);
		
		$survey_info=new survey_info([
		'taluka_id'=>$request->get('taluka_name'),
		'gram_id'=>$request->get('gram_name'),
		'name'=>$request->get('self_declaration_name'),
		'gram_name'=>$request->get('self_declaration_gram_name'),
		'name2'=>$request->get('bhogwatdar_name'),
		'survey_name'=>$request->get('survey_name'),
		'mbl'=>$request->get('mobile_number'),
		'adhar'=>$request->get('adhar_number'),
		'old_tax_no'=>$request->get('old_tax_number'),
		's_s_no'=>$request->get('s_s_number'),
		's_s_m'=>$request->get('s_s_s_m'),
		'group_no'=>$request->get('group_no'),
		'plot_no'=>$request->get('plot_no'),
		'yr_const'=>$request->get('yearcon'),
		'north_south'=>$request->get('north_south'),
		'east_west'=>$request->get('east_west'),
		'details'=>$d,
		'north'=>$request->get('north'),
		'south'=>$request->get('south'),
		'east'=>$request->get('east'),
		'west'=>$request->get('west'),
		'gate'=>$request->get('gate'),
		'status'=>$request->get('status')
		]);
		$data['status']="success";
		$data['msg']="data inserted";
		array_push($arr,$data);
		$survey_info->save();
		echo json_encode($arr);
		
	}
	public function surveydisplay()
	{
		$surveydata=array();
		$arr=array();
		$survey_i=DB::table('area_masters')
					->join('survey_infos','survey_infos.taluka_id','=','area_masters.id')
					->select('*','area_masters.id as aid')
					->get();
		$demo="";
		foreach($survey_i as $k)
		{
			$sur=$k->details;
			$name=$k->name;
			//echo $name;
			//exit();
			$decode=json_decode($sur);
			$data=array(
				$name,
				$k->taluka_id,
				$k->gram_id,
				$k->gram_name,
				$k->name2,
				$k->survey_name,
				$k->mbl,
				$k->adhar,
				$k->old_tax_no,
				$decode
			);
			array_push($surveydata,$data);
		}
		//var_dump($surveydata);
		echo json_encode($surveydata);
		//var_dump($d);
		//$data['status']="success";
		//array_push($arr,$data);
		//echo json_encode($arr);
	}
	public function statusinfo($id)
	{
		$area=survey_info::find($id);
		$s=$area->status;
		if($s=='active')
		{
			$area=survey_info::find($id);
			$area->status='inactive';
			$area->update();
			return redirect('/survey_info');
		}
		else if($s=='inactive')
		{
			$area=survey_info::find($id);
			$area->status='active';
			$area->update();
			return redirect('/survey_info');
		}
	}
	public function printdetails($id)
	{
		/*$users = DB::table('area_masters as A')
					->join('area_masters as B', 'A.id', '=', 'B.parent_id')
					->join('area_masters as C','A.id','=','C.super_id')
					->select('A.id AS jilla', 'B.id AS taluka','C.id as gram','C.id as gid','C.status as gstatus')
					->where('C.super_id','!=','0')
					->get();
		$arr=array();
		foreach($users as $k)
		{
			$getdata = DB::table('survey_infos')
					->where('jilla_id','=',$k->jilla)
					->where('taluka_id','=',$k->taluka)
					->where('id','=',$id)
					->get();
			array_push($arr,$getdata);	
			
		}
		//var_dump($arr);
		//exit();*/
		$arr=DB::table('survey_infos')
				->where('id','=',$id)
				->get();
		$varnan=varnan::get();

		$jillaname=DB::table('area_masters')
					->where('id','=',$arr[0]->jilla_id)
					->get();
		$talukaname=DB::table('area_masters')
					->where('id','=',$arr[0]->taluka_id)
					->get();
		$gramname=DB::table('area_masters')
					->where('id','=',$arr[0]->gram_id)
					->get();
					

		$data="";
		foreach($arr as $testsurvey)
		{
			$data=$testsurvey->details;
		}
		$survey=json_decode($data);
		$readyreknals=DB::table('readyreknals')
					->where('jilla','=',$arr[0]->jilla_id)
					->where('taluka','=',$arr[0]->taluka_id)
					->where('gram','=',$arr[0]->gram_id)
					->get();

		$bharank=DB::table('bharanks')
				->where('jilla','=',$arr[0]->jilla_id)
				->where('taluka','=',$arr[0]->taluka_id)
				->where('gram','=',$arr[0]->gram_id)
				->get();
		$gha=DB::table('ghasaras')
				->where('jilla','=',$arr[0]->jilla_id)
				->where('taluka','=',$arr[0]->taluka_id)
				->where('gram','=',$arr[0]->gram_id)
				->get();
		$additional=DB::table('additional_details')
				->where('jilla','=',$arr[0]->jilla_id)
				->where('taluka','=',$arr[0]->taluka_id)
				->where('gram','=',$arr[0]->gram_id)
				->get();
		return view('backend.printdetails',compact('arr','varnan','survey','readyreknals','gha','jillaname','talukaname','gramname','additional','bharank'));
	}
}
