@extends('backend.header')
@section('index-content')

				<section role="main" class="content-body">
					<header class="page-header">
						<h2>Survey Details Form</h2>
					
						<div class="right-wrapper pull-right">
							<ol class="breadcrumbs">
								<li>
									<a href="/">
										<i class="fa fa-home"></i>
									</a>
								</li>
								<li><span>Form</span></li>
								<li><span>Survey Details</span></li>
							</ol>
					
							<a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
						</div>
					</header>

					<!-- start: page -->
					<div class="row">
						<div class="col-md-10">
							<form id="form" action="{{route('survey_detail.store')}}" class="form-horizontal" method="post">
							@csrf
								<section class="panel">
									<header class="panel-heading">
										<div class="panel-actions">
											<a href="#" class="fa fa-caret-down"></a>
											<a href="#" class="fa fa-times"></a>
										</div>

										<h2 class="panel-title">Survey Details Form</h2>
										<!--<p class="panel-subtitle">
											Basic validation will display a label with the error after the form control.
										</p>-->
									</header>
									<div class="panel-body">
										<div class="form-group">
											<label class="col-sm-3 control-label">Survey Name <span class="required">*</span></label>
											<div class="col-sm-9">
												<select name="survey_name" class="form-control">
												<option value="">Select Survey Name</option>
												@foreach($survey_info as $ai)
												<option value="{{$ai->id}}">{{$ai->name}}</option>
												
												@endforeach
												</select>
												@error('survey_name')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label"> Type Of Income<span class="required">*</span></label>
											<div class="col-sm-9">
												<select name="income_type" class="form-control">
												<option value="">Select Type Of Income</option>
												
												<option value="A hut or a mud house">A hut or a mud house</option>
												<option value="Stone brick mud house">Stone brick mud house</option>
												<option value="Stone brick cement house">Stone brick cement house</option>
												<option value="RCC Construction">RCC Construction</option>
												<option value="Open space">Open space</option>
												
												
												</select>
												@error('income_type')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">Sq.ft <span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="sq_ft" class="form-control">
												@error('sq_ft')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">Sq.mtr <span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="sq_mtr" class="form-control">
												@error('sq_mtr')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">Redeemer rates <span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="red_rates" class="form-control">
												@error('red_rates')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">Depreciation rate <span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="dep_rates" class="form-control">
												@error('dep_rates')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">Weighted rate <span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="weight_rates" class="form-control">
												@error('weight_rates')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">Total <span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="total" class="form-control">
												@error('total')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
											
										</div>
										
									</div>
									<footer class="panel-footer">
										<div class="row">
											<div class="col-sm-9 col-sm-offset-3">
												<button class="btn btn-primary" type="submit">Submit</button>
												<!--<button type="reset" class="btn btn-default">Reset</button>-->
											</div>
										</div>
									</footer>
								</section>
							</form>
						</div>
						
					</div>
					</section>
					<!-- end: page -->
				@stop