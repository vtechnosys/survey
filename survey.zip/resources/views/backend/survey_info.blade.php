@extends('backend.header')
@section('index-content')

				<section role="main" class="content-body">
					<header class="page-header">
						<h2> सर्वेक्षण फॉर्म</h2>
					
						<div class="right-wrapper pull-right">
							<ol class="breadcrumbs">
								<li>
									<a href="/">
										<i class="fa fa-home"></i>
									</a>
								</li>
								<li><span>फॉर्म</span></li>
								<li><span> सर्वेक्षण</span></li>
							</ol>
					
							<a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
						</div>
					</header>

					<!-- start: page -->
					<div class="row">
						<div class="col-md-12">
							<form id="form" action="{{route('survey_info.store')}}" class="form-horizontal" method="post" enctype="multipart/form-data">
							@csrf
								<section class="panel">
									<header class="panel-heading">
										<div class="panel-actions">
											<a href="#" class="fa fa-caret-down"></a>
											<a href="#" class="fa fa-times"></a>
										</div>

										<h2 class="panel-title"> सर्वेक्षण फॉर्म</h2>
										<!--<p class="panel-subtitle">
											Basic validation will display a label with the error after the form control.
										</p>-->
									</header>
									<div class="panel-body">
										<div class="form-group">
											<label class="col-sm-3 control-label">जिल्हा नाव</label>
											<div class="col-sm-9">
												<select name="jilla_id" class="form-control" id="jilla_id">
												<option value="">जिल्हा नाव</option>
												@foreach($jilla as $ai)
												<option value="{{$ai->id}}">{{$ai->area_name}}</option>
												
												@endforeach
												</select>
													
											</div>
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">तालुका </label>
											<div class="col-sm-9">
												<select name="taluka_name" class="form-control" id="taluka" required>
												<option value="">तालुका</option>
												</select>
												@error('taluka_name')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">ग्रामपंचायत </label>
											<div class="col-sm-9">
												<select name="gram_name" class="form-control" id="gram_id">
												<option value="">ग्रामपंचायत</option>
												</select>
											</div>
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">स्वयंघोषणापत्र  करुन देणार
											</label>
											<div class="col-sm-9">
												<input type="text" name="self_declaration_name" class="form-control" required>
												@error('self_declaration_name')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">स्वयंघोषणापत्र  करुन घेणार
											</label>
											<div class="col-sm-9">
												<input type="text" name="self_declaration_gram_name" class="form-control" required>
												@error('self_declaration_gram_name')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">भोगवटदाराचे नांव
											</label>
											<div class="col-sm-9">
												<input type="text" name="bhogwatdar_name" class="form-control" required>
												@error('bhogwatdar_name')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">सिटीसव्‍ह मिळकत धारकाचे नांव
											</label>
											<div class="col-sm-9">
												<input type="text" name="survey_name" class="form-control" >
												@error('survey_name')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">मोबाइल नं 
											</label>
											<div class="col-sm-9">
												<input type="text" name="mobile_number" class="form-control" required>
												@error('mobile_number')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">आधार नं</label>
											<div class="col-sm-9">
												<input type="text" name="adhar_number" class="form-control" required>
												@error('adhar_number')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">पत्नीचे मोबाइल नं
											</label>
											<div class="col-sm-9">
												<input type="text" name="wife_mobile_number" class="form-control">
												@error('wife_mobile_number')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">पत्नीचे आधार नं
											</label>
											<div class="col-sm-9">
												<input type="text" name="wife_adhar_number" class="form-control" required>
												@error('wife_adhar_number')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">Image Upload
											</label>
											<div class="col-sm-9">
												<input type="file" name="img" class="form-control">
												@error('img')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">Map Upload</label>
											<div class="col-sm-9">
												<input type="file" name="mapimg" class="form-control">
												@error('mapimg')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">जुना मिळकत क्र </label>
											<div class="col-sm-9">
												<input type="text" name="old_tax_number" class="form-control">
												@error('old_tax_number')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label"> मिळकत क्र </label>
											<div class="col-sm-9">
												<input type="text" name="tax_number" class="form-control" required>
												@error('tax_number')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">सि.स.नं.</label>
											<div class="col-sm-9">
												<input type="text" name="s_s_number" class="form-control">
												@error('s_s_number')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">सि.स.चौ.मि.</label>
											<div class="col-sm-9">
												<input type="text" name="s_s_s_m" class="form-control">
												@error('s_s_s_m')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">गट नं.</label>
											<div class="col-sm-9">
												<input type="text" name="group_no" class="form-control">
												@error('group_no')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">प्लॉट नं.</label>
											<div class="col-sm-9">
												<input type="text" name="plot_no" class="form-control">
												@error('plot_no')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">उत्तर / दक्षिण </label>
											<div class="col-sm-9">
												<input type="text" name="north_south" class="form-control" required>
												@error('north_south')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">पुर्व / पश्चिम 
											</label>
											<div class="col-sm-9">
												<input type="text" name="east_west" class="form-control" required>
												@error('east_west')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
											
										</div>
										<table id="t">
  <colgroup>
    <col class="w">
    <col>
    <col>
    <col>
  </colgroup>
  <thead>
    <tr>
											<th>मिळकतीचे वर्णन</th>
											<th>Property Name</th>
											<th>बांधकाम वर्ष</th>
											<th>बांधकाम वय वर्ष</th>
											<th>Floor</th>
											<th>चाै.फुट</th>
											<th>चाै.मि.</th>
											<!-- <th>रेडिरेकनरचे दर</th>
											<th>घसार दर</th>
											<th>भारांक</th> -->
											<!--<th>एकुण कर</th>-->
										</tr>
  </thead>
  <tbody>
	<?php
	$i=1;
	?>
	@foreach($varanan as $v)
    <tr>
      <td><?php echo $i;?>. {{$v->name}}<input type="hidden" name="varnan<?php echo $i;?>" value="{{$v->name}}"></td>
	  <td><select name="property_name<?php echo $i;?>" id="property_name<?php echo $i;?>" class="property_name">
	  <option value="">Select</option>
		  <option value="निवासी">निवासी</option>
		  <option value="वाणिजक">वाणिजक</option>
		  <option value="औधोगिक">औधोगिक</option>
	  </select></td> 
	  <td><input type="text" name="yercon<?php echo $i;?>" class="yercon" id="yercon<?php echo $i;?>" style="width:60px;"></input></td>
	  <td><select name="conyerage<?php echo $i;?>" id="conyerage<?php echo $i;?>" class="conyerage">
	  <option value="">Select</option>
		  <option value="one">०-२</option>
		  <option value="two">३-५</option>
		  <option value="three">६-१०</option>
		  <option value="four">११-२०</option>
		  <option value="five">२१-३०</option>
		  <option value="six">३१-४०</option>
		  <option value="seven">४१-५०</option>
		  <option value="eight">५१-६०</option>
		  <option value="greater_than_sixty">६१ पेक्षा जास्त</option>
	  </select></td> 
	  <td><input type="text" name="floor<?php echo $i;?>" class="floor" id="floor<?php echo $i;?>" style="width:60px;"></input></td>
	  <td><input type="text"  name="chf<?php echo $i;?>" class="chfdemo" id="chf<?php echo $i;?>" style="width:60px;" autocomplete="off"></input></td>
	  <td><input type="text"  name="chm<?php echo $i;?>"class="chm" id="chm<?php echo $i;?>" style="width:60px;" autocomplete="off"></input></td>
	 <!--<td><input type="text"  name="tol<?php //echo $i;?>" id="tol<?php //echo $i;?>" style="width:60px;"></input></td>-->
	</tr>
	<?php
	$i++;
	?>
	@endforeach
	<input type="hidden" value="<?php echo $i;?>" id="rowcount">
    </tr>
	
  </tbody>
</table>
		<div class="form-group">
		<label class="col-sm-3 control-label">Total Sq.ft 
		</label>
		<div class="col-sm-9">
		<input type="text" name="tolsqft" class="form-control"  id="tolsqft" required>
		@error('tolsqft')
		<font size="3" color="red">{{$message}}</font>
		@enderror	
		</div>
		</div> 
										<div class="form-group">
											<label class="col-sm-3 control-label">नळ कनेक्शन 
											</label>
											<div class="col-sm-9">
												<select name="nalcon" class="form-control" required>
													<option value="Yes">Yes</option>
													<option value="No">No</option>
												</select>
												@error('nalcon')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label"> शाैचालय
											</label>
											<div class="col-sm-9">
											<select name="washroom" class="form-control" required>
													<option value="Yes">Yes</option>
													<option value="No">No</option>
												</select>
												@error('washroom')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-1 control-label">चर्तु:सिमा</label>
											<label class="col-sm-2 control-label"> उत्तर 
											</label>
											<div class="col-sm-9">
												<input type="text" name="north" class="form-control" required>
												@error('north')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
											
										</div>
										<div class="form-group">
										<label class="col-sm-1 control-label">चर्तु:सिमा</label>
											<label class="col-sm-2 control-label">दक्षिण 
											</label>
											<div class="col-sm-9">
												<input type="text" name="south" class="form-control" required>
												@error('south')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
											
										</div>
										<div class="form-group">
										<label class="col-sm-1 control-label">चर्तु:सिमा</label>
											<label class="col-sm-2 control-label">पूर्व 
											</label>
											<div class="col-sm-9">
												<input type="text" name="east" class="form-control" required>
												@error('east')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
											
										</div>
										<div class="form-group">
										<label class="col-sm-1 control-label">चर्तु:सिमा</label>
											<label class="col-sm-2 control-label">पश्चिम 
											</label>
											<div class="col-sm-9">
												<input type="text" name="west" class="form-control" required>
												@error('west')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">व्दार 
											</label>
											<div class="col-sm-9">
												<input type="text" name="gate" class="form-control" >
												@error('gate')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
											
										</div>
										
									</div>
									<footer class="panel-footer">
										<div class="row">
											<div class="col-sm-9 col-sm-offset-3">
												<button class="btn btn-primary" type="submit">Submit</button>
												<!--<button type="reset" class="btn btn-default">Reset</button>-->
											</div>
										</div>
									</footer>
								</section>
							</form>
						</div>
						
					</div>
					<!-- end: page -->
				</section>
				<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
				<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
		<script>
		$(document).ready(function(){
		$("#gram_id").on("change",function()
   		 	{
        		var id=$(this).val();
				//alert(id);
				var data={
				jilla_id:$("#jilla_id").val(),
				taluka_id:$("#taluka").val(),
				gram_id:$(this).val()
			}
			//console.log(data);
			$.ajax({
			url:'/api/gramdata/',
			method:'get',
			data:data,
			success:function(data)
			{
				var test=data.split("::");
				var $row=$("#rowcount").val();
				$i=1;
				for($j=6; $j<=8; $j++)
				{
					$("#bharank"+$j).val(test[0+$i-1]);
					$i++;
				}
				for($i=1; $i<$row-2; $i++)
				{
					$("#ready"+$i).val(test[2+$i]);
					//alert($i);
				}
				
			},
			error:function(data)
			{
				alert(data);
			}
		});
		});
		$("#yearcon").on("change",function(){
			var id=$(this).val();
			var date=new Date().getFullYear();
			var remd=date-id;
			var data={
				jilla_id:$("#jilla_id").val(),
				taluka_id:$("#taluka").val(),
				gram_id:$("#gram_id").val(),
				yearcin:remd
			}
			$.ajax({
				url:'/api/getghasara/',
				method:'get',
				data:data,
				success:function(data)
				{
					var test=data.split("::");
					$("#ghasara1").val(test[0])
					for($k=2; $k<=5; $k++)
					{
						$("#ghasara"+$k).val(test[0+$k-1]);
					}
				},
				error:function(data)
				{
					//alert(data);
				}

			});
		});
		
			
			$(".chfdemo").on("change",function(){
			var chf=$(this).val();
			//alert(chf);
			var test=chf/10.76;
			$(".chm").on('click',function() {
    			
					$(this).val(test);
				
				})
			
			
			
			});
			
			
			
		
		});
		</script>
		
		
	@stop