@extends('backend.header')
@section('index-content')

				<section role="main" class="content-body">
					<header class="page-header">
						<h2>तालुका फॉर्म </h2>
					
						<div class="right-wrapper pull-right">
							<ol class="breadcrumbs">
								<li>
									<a href="/">
										<i class="fa fa-home"></i>
									</a>
								</li>
								<li><span>फॉर्म</span></li>
								<li><span>तालुका</span></li>
							</ol>
					
							<a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
						</div>
					</header>

					<!-- start: page -->
					<div class="row">
						<div class="col-md-10">
							<form id="form" action="{{route('taluka.store')}}" class="form-horizontal" method="post">
							@csrf
								<section class="panel">
									<header class="panel-heading">
										<div class="panel-actions">
											<a href="#" class="fa fa-caret-down"></a>
											<a href="#" class="fa fa-times"></a>
										</div>

										<h2 class="panel-title">तालुका फॉर्म</h2>
										<!--<p class="panel-subtitle">
											Basic validation will display a label with the error after the form control.
										</p>-->
									</header>
									<div class="panel-body">
										<div class="form-group">
											<label class="col-sm-3 control-label">जिल्हा नाव<span class="required">*</span></label>
											<div class="col-sm-9">
												<select name="जिल्हा_नाव" class="form-control" required>
												<option value="">जिल्हा नाव</option>
												@foreach($jilla as $ai)
												<option value="{{$ai->id}}">{{$ai->area_name}}</option>
												
												@endforeach
												</select>
													
											</div>
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">तालुका नाव<span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" 
												name="तालुका_नाव" class="form-control" required>
												@error('तालुका_नाव')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
										</div>
										
									</div>
									<footer class="panel-footer">
										<div class="row">
											<div class="col-sm-9 col-sm-offset-3">
												<button class="btn btn-primary" type="submit">Submit</button>
												<!--<button type="reset" class="btn btn-default">Reset</button>-->
											</div>
										</div>
									</footer>
								</section>
							</form>
						</div>
						
					</div>
					<!-- end: page -->
					<!-- start: page -->
					<section class="panel">
							<header class="panel-heading">
								<div class="panel-actions">
									<a href="#" class="fa fa-caret-down"></a>
									<a href="#" class="fa fa-times"></a>
								</div>
						
								<h2 class="panel-title">तालुका तपशील</h2>
							</header>
							<div class="panel-body">
								<table class="table table-bordered table-striped mb-none" id="datatable-default">
									<thead>
										<tr>
											<th>तालुका क्र. </th>
											<th>Jilla Name</th>
											<th>तालुका नाव</th>
											
											<th>Status</th>
											<th>Edit</th>
											
										</tr>
									</thead>
									<tbody>
									<?php
									$i=1;
									?>
									@foreach($users as $a)
									<tr class="gradeX">
											<td>{{$a->tid}}</td>
											<td>{{$a->jilla}}</td>
											<td>{{$a->taluka}}</td>
											<?php 
											$s=$a->tstatus;
											if($s=='active')
											{
											?>
											<td><a href="/statuschktaluka/{{$a->tid}}" class="btn btn-success" id="statuschk" value="{{$a->tid}}">{{$a->tstatus}}</a></td>
											<?php
											}else{
											?>
											<td><a href="/statuschktaluka/{{$a->tid}}" class="btn btn-warning" id="statuschk" value="{{$a->tid}}">{{$a->tstatus}}</a></td>
											<?php
											}
											?>
											<td class="actions">
												
											<button class="btn btn-primary"><a href="{{route('taluka.edit',$a->tid)}}" style="text-decoration:none;color:white;" class="on-default edit-row">Edit</a></button></td>
												
											
									</tr>
									<?php
									$i++
									?>
									@endforeach
									
									</tbody>
								</table>
							</div>
						</section>
				</section>
				
			@stop