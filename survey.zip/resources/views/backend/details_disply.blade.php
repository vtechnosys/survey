<?php
foreach($bharank as $bh)
{
    $d=$bh->amt;
    $json_array=json_decode( preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $d),true);
    $arr=array();
    foreach($json_array as $key=>$arrays){
        foreach($arrays as $value){
            
                array_push($arr,$value);
            
        }
        echo "</br>";
    }
}
echo $arr[0];
echo $arr[1];
echo $arr[2];
echo $arr[3];
echo $arr[4];
echo $arr[5];

?>