@extends('backend.header')
@section('index-content')
				<section role="main" class="content-body">
					<header class="page-header">
						<h2> वापरकर्ता फॉर्म</h2>
					
						<div class="right-wrapper pull-right">
							<ol class="breadcrumbs">
								<li>
									<a href="/">
										<i class="fa fa-home"></i>
									</a>
								</li>
								<li><span>फॉर्म</span></li>
								<li><span> वापरकर्ता</span></li>
							</ol>
					
							<a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
						</div>
					</header>

					<!-- start: page -->
					<div class="row">
						<div class="col-md-10">
							<form id="form" action="{{route('user.store')}}" class="form-horizontal" method="post">
							@csrf
								<section class="panel">
									<header class="panel-heading">
										<div class="panel-actions">
											<a href="#" class="fa fa-caret-down"></a>
											<a href="#" class="fa fa-times"></a>
										</div>

										<h2 class="panel-title"> वापरकर्ता फॉर्म</h2>
										<!--<p class="panel-subtitle">
											Basic validation will display a label with the error after the form control.
										</p>-->
									</header>
									<div class="panel-body">
										<div class="form-group">
											<label class="col-sm-3 control-label"> वापरकर्ता नाव <span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="user_name" class="form-control" required>
												@error('user_name')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">मोबाईल नंबर <span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="mobile_number" class="form-control" required>
												@error('mobile_number')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">पासवर्ड <span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="password" name="password" class="form-control" required>
												@error('password')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
										</div>
										
									</div>
									<footer class="panel-footer">
										<div class="row">
											<div class="col-sm-9 col-sm-offset-3">
												<button class="btn btn-primary" type="submit">Submit</button>
												<!--<button type="reset" class="btn btn-default">Reset</button>-->
											</div>
										</div>
									</footer>
								</section>
							</form>
						</div>
						
					</div>
					<!-- end: page -->
					<!-- start: page -->
					<section class="panel">
							<header class="panel-heading">
								<div class="panel-actions">
									<a href="#" class="fa fa-caret-down"></a>
									<a href="#" class="fa fa-times"></a>
								</div>
						
								<h2 class="panel-title">वापरकर्ता तपशील</h2>
							</header>
							<div class="panel-body">
								<table class="table table-bordered table-striped mb-none" id="datatable-default">
									<thead>
										<tr>
											<th>वापरकर्ता क्र.</th>
											<th>वापरकर्ता नाव</th>
											<th>मोबाईल नंबर</th>
											<th>पासवर्ड</th>
											<th>Status</th>
											<th>Edit</th>
											
											
										</tr>
									</thead>
									<tbody>
									@foreach($regi as $a)
									<tr class="gradeX">
											<td>{{$a->id}}</td>
											<td>{{$a->name}}</td>
											<td>{{$a->mobile}}</td>
											<td>{{$a->password}}</td>
												<?php 
											$s=$a->status;
											if($s=='active')
											{
											?>
											<td><a href="/userstatusupdate/{{$a->id}}" class="btn btn-success" id="statuschk" value="{{$a->id}}">{{$a->status}}</a></td>
											<?php
											}else{
											?>
											<td><a href="/userstatusupdate/{{$a->id}}" class="btn btn-warning" id="statuschk" value="{{$a->id}}">{{$a->status}}</a></td>
											<?php
											}
											?>
											<td class="actions">
												
												<a href="{{route('user.edit',$a->id)}}" class="on-default edit-row"><button>Edit</button></a></td>
												<!--<td><form action="{{route('user.destroy',$a->id)}}" method="post">
												@csrf
												@method('DELETE')
												<input type="submit" class="on-default remove-row" value="Delete">
												</form>
											</td>-->
											
									</tr>
									@endforeach
									</tbody>
								</table>
							</div>
						</section>
				</section>
			@stop