@extends('backend.header')
@section('index-content')
				<section role="main" class="content-body">
					<header class="page-header">
						<h2>तालुका तपशील</h2>
					
						<div class="right-wrapper pull-right">
							<ol class="breadcrumbs">
								<li>
									<a href="/">
										<i class="fa fa-home"></i>
									</a>
								</li>
								<li><span>टेबल</span></li>
								<li><span>तालुका</span></li>
							</ol>
					
							<a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
						</div>
					</header>

					<!-- start: page -->
						<section class="panel">
							<header class="panel-heading">
								<div class="panel-actions">
									<a href="#" class="fa fa-caret-down"></a>
									<a href="#" class="fa fa-times"></a>
								</div>
						
								<h2 class="panel-title">तालुका तपशील</h2>
							</header>
							<div class="panel-body">
								<table class="table table-bordered table-striped mb-none" id="datatable-default">
									<thead>
										<tr>
											<th>तालुका क्र. </th>
											<th>तालुका नाव</th>
											
											<th>Status</th>
											<th>Edit</th>
											
										</tr>
									</thead>
									<tbody>
									<?php
									$i=1;
									?>
									@foreach($p as $a)
									<tr class="gradeX">
											<td>{{$a->id}}</td>
											<?php 
											if($a->parent_id==0)
											{
											?>
											<td>{{$a->area_name}}</td>
											<td>0</td>
											<?php
											}else{
											?>
											<td>0</td>
											<td>{{$a->area_name}}</td>
											<?php
											}
											?>
											<td>{{$a->status}}</td>
											<td class="actions">
											<button class="btn btn-primary"><a href="{{route('taluka.edit',$a->id)}}" class="on-default edit-row" style="text-decoration:none;color:white;">Edit</a></button>
											</td>
									</tr>
									<?php
									$i++
									?>
									@endforeach
									
									</tbody>
								</table>
							</div>
						</section>
						
						
						
						
					<!-- end: page -->
				</section>
			@stop