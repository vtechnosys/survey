@extends('backend.header')
@section('index-content')

				<section role="main" class="content-body">
					<header class="page-header">
						<h2> सर्वेक्षण फॉर्म</h2>
					
						<div class="right-wrapper pull-right">
							<ol class="breadcrumbs">
								<li>
									<a href="/">
										<i class="fa fa-home"></i>
									</a>
								</li>
								<li><span>फॉर्म</span></li>
								<li><span> सर्वेक्षण</span></li>
							</ol>
					
							<a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
						</div>
					</header>
					<!-- start: page -->
					<div class="row">
						<div class="col-md-12">
							<form id="form" action="{{route('survey_info.update',$gram_name[0]->id)}}" class="form-horizontal" method="post">
							@csrf
							@method('PATCH')
								<section class="panel">
									<header class="panel-heading">
										<div class="panel-actions">
											<a href="#" class="fa fa-caret-down"></a>
											<a href="#" class="fa fa-times"></a>
										</div>

										<h2 class="panel-title"> सर्वेक्षण फॉर्म</h2>
										<!--<p class="panel-subtitle">
											Basic validation will display a label with the error after the form control.
										</p>-->
									</header>
									<div class="panel-body">
									<div class="form-group">
											<label class="col-sm-3 control-label">जिल्हा नाव<span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" value="{{$jillaselect[0]->area_name}}" name="jilla_id" class="form-control" id="jilla_id">
												
											</div>
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">तालुका <span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="taluka_name" class="form-control" id="taluka" value="{{$talukaselect[0]->area_name}}"required> 
												
											</div>
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">ग्रामपंचायत<span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="gram_name" class="form-control" id="gram_id" value="{{$gramselect[0]->area_name}}" required>
												
											</div>
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">स्वयंघोषणापत्र  करुन देणार <span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="self_declaration_name" class="form-control" value="{{$gram_name[0]->name}}"required >
												@error('self_declaration_name')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">स्वयंघोषणापत्र  करुन घेणार<span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="self_declaration_gram_name" class="form-control" value="{{$gram_name[0]->gram_name}}" required>
												@error('self_declaration_gram_name')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">भोगवटदाराचे नांव<span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="bhogwatdar_name" class="form-control" value="{{$gram_name[0]->name2}}" required>
												@error('bhogwatdar_name')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">सिटीसव्‍ह मिळकत धारकाचे नांव<span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="survey_name" class="form-control" value="{{$gram_name[0]->survey_name}}" required>
												@error('survey_name')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">मोबाइल नं<span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="mobile_number" class="form-control" value="{{$gram_name[0]->mbl}}" required>
												@error('mobile_number')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">आधार नं<span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="adhar_number" class="form-control" value="{{$gram_name[0]->adhar}}" required>
												@error('adhar_number')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">पत्नीचे मोबाइल नं <span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="wife_mobile_number" class="form-control" required value="{{$gram_name[0]->wife_mbl}}">
												@error('wife_mobile_number')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">पत्नीचे आधार नं<span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="wife_adhar_number" class="form-control" required value="{{$gram_name[0]->wife_adhar}}">
												@error('wife_adhar_number')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
											
										</div>
										<div class="form-group">
										<label class="col-sm-3 control-label">Image<span class="required">*</span></label>
										<div class="col-sm-9">
										<img src="{{asset('image')}}/{{$gram_name[0]->img}}" height="150px" width="150px" value="{{$gram_name[0]->img}}" name="prvimg">
										</div>
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">Image Uplode<span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="file" name="img" class="form-control">
												@error('img')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
											
										</div>
										<div class="form-group">
										<label class="col-sm-3 control-label">Map Image<span class="required">*</span></label>
										<div class="col-sm-9">
										<img src="{{asset('image')}}/{{$gram_name[0]->mapimg}}" height="150px" width="150px" value="{{$gram_name[0]->mapimg}}" name="premapimg">
										</div>
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">Map Uplode<span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="file" name="mapimg" class="form-control">
												@error('mapimg')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
											
										</div>

										<div class="form-group">
											<label class="col-sm-3 control-label">जुना मिळकत क्र<span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="old_tax_number" class="form-control" value="{{$gram_name[0]->old_tax_no}}" required>
												@error('old_tax_number')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">सि.सि नं.<span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="s_s_number" class="form-control" value="{{$gram_name[0]->s_s_no}}" required>
												@error('s_s_number')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">सि. सि. चैा मि.<span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="s_s_s_m" class="form-control" value="{{$gram_name[0]->s_s_m}}" required>
												@error('s_s_s_m')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">गट नं.<span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="group_no" class="form-control" value="{{$gram_name[0]->group_no}}" required>
												@error('group_no')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">प्लॉट नं.<span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="plot_no" class="form-control" value="{{$gram_name[0]->plot_no}}" required>
												@error('plot_no')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
											
										</div>
										
										<div class="form-group">
											<label class="col-sm-3 control-label">उत्तर / दक्षिण<span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="north_south" class="form-control" value="{{$gram_name[0]->north_south}}" required>
												@error('north_south')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">पुर्व / पश्चिम <span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="east_west" class="form-control" value="{{$gram_name[0]->east_west}}"required>
												@error('east_west')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
											
										</div>
										<table id="t">
  <colgroup>
    <col class="w">
    <col>
    <col>
    <col>
  </colgroup>
  <thead>
    <tr>
											<th>मिळकतीचे वर्णन</th>
											<th>Property Name</th>
											<th>बांधकाम वर्ष</th>
											<th>बांधकाम वय वर्ष</th>
											<th>Floor</th>
											<th>चाै.फुट</th>
											<th>चाै.मि.</th>
											<!-- <th>रेडिरेकनरचे दर</th>
											<th>घसार दर</th>
											<th>भारांक</th> -->
											<th>एकुण कर</th>
										</tr>
  </thead>
  <tbody>
	<?php
	$i=1;
	?>
	@foreach($k as $v)
    <tr onclick="myGeeks(this)">
      <td><?php echo $i;?>. {{$v->varnana_name}}<input type="hidden" name="varnan<?php echo $i;?>" value="{{$v->varnana_name}}"></td>
	  <td><input type="text" name="property_name<?php echo $i;?>" value="{{$v->property_name}}" id="property_name<?php echo $i;?>" class="property_name">
	  	</td> 
	  <td><input type="text" name="yercon<?php echo $i;?>" class="yercon" id="yercon<?php echo $i;?>" style="width:60px;" value="{{$v->yercon}}"></input></td>
	  <td><input type="text" name="conyerage<?php echo $i;?>" value="{{$v->conyerage}}" id="conyerage<?php echo $i;?>" class="conyerage">
</td> 
	  <td><input type="text" name="floor<?php echo $i;?>" class="floor" id="floor<?php echo $i;?>" style="width:60px;" value="{{$v->floor}}"></input></td>
	  <td><input type="text" name="chf<?php echo $i;?>" class="chf" value="{{$v->ch_fu}}" id="chf<?php echo $i;?>" style="width:60px;"></input></td>
	  <td><input type="text"  name="chm<?php echo $i;?>"class="chm1" value="{{$v->ch_me}}" id="chm<?php echo $i;?>" style="width:60px;"></input></td>
	 <td><input type="text"  name="tol<?php echo $i;?>" id="tol<?php echo $i;?>" value="{{$v->total}}" style="width:60px;"></input></td>
	</tr>
	<?php
	$i++;
	?>
	@endforeach
	<input type="hidden" value="<?php echo $i;?>" id="rowcount">
    </tr>
	
  </tbody>
</table>
								<div class="form-group">
											<label class="col-sm-3 control-label">Total Sq.ft <span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="total_sqft" class="form-control" value="{{$gram_name[0]->total_sqft}}">
												@error('total_sqft')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
											
										</div>
								<div class="form-group">
											<label class="col-sm-3 control-label">नळ कनेक्शन <span class="required">*</span></label>
											<div class="col-sm-9">
												<select name="nalcon" class="form-control" >
													<option value="{{$gram_name[0]->nal}}">{{$gram_name[0]->nal}}</option>
													
												</select>
												@error('nalcon')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label"> शाैचालय <span class="required">*</span></label>
											<div class="col-sm-9">
											<select name="washroom" class="form-control" >
											<option value="{{$gram_name[0]->washroom}}">{{$gram_name[0]->washroom}}</option>
													
													
												</select>
												@error('washroom')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">उत्तर <span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="north" class="form-control" value="{{$gram_name[0]->north}}" required>
												@error('north')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">दक्षिण <span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="south" class="form-control" value="{{$gram_name[0]->south}}" required>
												@error('south')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">पूर्व <span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="east" class="form-control" value="{{$gram_name[0]->east}}"required>
												@error('east')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">पश्चिम <span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="west" class="form-control" value="{{$gram_name[0]->west}}"required>
												@error('west')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">व्दार <span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="gate" class="form-control" value="{{$gram_name[0]->gate}}"required>
												@error('gate')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
											
										</div>
										<br><br>
									</div>
																</section>
							</form>
						</div>
						
					</div>
					<!-- end: page -->
				</section>
			@stop