@extends('backend.header')
@section('index-content')

				<section role="main" class="content-body">
					<header class="page-header">
						<h2>जिल्हा फॉर्म </h2>
					
						<div class="right-wrapper pull-right">
							<ol class="breadcrumbs">
								<li>
									<a href="/">
										<i class="fa fa-home"></i>
									</a>
								</li>
								<li><span>फॉर्म</span></li>
								<li><span>जिल्हा</span></li>
							</ol>
					
							<a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
						</div>
					</header>

					<!-- start: page -->
					<div class="row">
						<div class="col-md-10">
							<form id="form" action="/jillaupdate/{{$jilla->id}}" method="post" class="form-horizontal">
							@csrf
                            <section class="panel">
									<header class="panel-heading">
										<div class="panel-actions">
											<a href="#" class="fa fa-caret-down"></a>
											<a href="#" class="fa fa-times"></a>
										</div>

										<h2 class="panel-title">जिल्हा फॉर्म</h2>
										<!--<p class="panel-subtitle">
											Basic validation will display a label with the error after the form control.
										</p>-->
									</header>
									<div class="panel-body">
										<div class="form-group">
											<label class="col-sm-3 control-label">जिल्हा नाव<span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" 
												name="जिल्हा_नाव" class="form-control" value="{{$jilla->area_name}}">
												@error('जिल्हा_नाव')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
										</div>
										<!--<div class="form-group">
											<label class="col-sm-3 control-label">Status (Active/Inactive)<span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="status" class="form-control" value="{{$jilla->status}}">
												@error('status')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
											
										</div>-->
										
									</div>
									<footer class="panel-footer">
										<div class="row">
											<div class="col-sm-9 col-sm-offset-3">
												<button class="btn btn-primary" type="submit">Submit</button>
												<!--<button type="reset" class="btn btn-default">Reset</button>-->
											</div>
										</div>
									</footer>
								</section>
							</form>
						</div>
						
					</div>
					<!-- end: page -->
				</section>
			@stop