@extends('backend.header')
@section('index-content')
				<section role="main" class="content-body">
					<header class="page-header">
						<h2> वापरकर्ता फॉर्म</h2>
					
						<div class="right-wrapper pull-right">
							<ol class="breadcrumbs">
								<li>
									<a href="/">
										<i class="fa fa-home"></i>
									</a>
								</li>
								<li><span>फॉर्म</span></li>
								<li><span> वापरकर्ता</span></li>
							</ol>
					
							<a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
						</div>
					</header>


					<!-- start: page -->
					<div class="row">
						<div class="col-md-10">
							<form id="form" action="{{route('user.update',$regi->id)}}" class="form-horizontal" method="post">
							@csrf
							@method('PATCH')
								<section class="panel">
									<header class="panel-heading">
										<div class="panel-actions">
											<a href="#" class="fa fa-caret-down"></a>
											<a href="#" class="fa fa-times"></a>
										</div>

										<h2 class="panel-title">वापरकर्ता फॉर्म</h2>
										<!--<p class="panel-subtitle">
											Basic validation will display a label with the error after the form control.
										</p>-->
									</header>
									<div class="panel-body">
										<div class="form-group">
											<label class="col-sm-3 control-label">वापरकर्ता नाव <span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="user_name" class="form-control" value="{{$regi->name}}" required>
												@error('user_name')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">मोबाईल नंबर <span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="mobile_number" class="form-control" value="{{$regi->mobile}}" required>
												@error('mobile_number')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">पासवर्ड <span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="password" class="form-control" value="{{$regi->password}}" required>
												@error('password')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
										</div>
										
									</div>
									<footer class="panel-footer">
										<div class="row">
											<div class="col-sm-9 col-sm-offset-3">
												<button class="btn btn-primary" type="submit">Update</button>
												<!--<button type="reset" class="btn btn-default">Reset</button>-->
											</div>
										</div>
									</footer>
								</section>
							</form>
						</div>
						
					</div>
					<!-- end: page -->
				</section>
			@stop