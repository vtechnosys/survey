<?php
$str="<option>select</option>";
foreach($jillaid as $j)
{
    $str.="<option value='$j->id'>".$j->area_name."</option>";
}
echo $str;
?>