@extends('backend.header')
@section('index-content')
<div class="row">
						
				
				<section role="main" class="content-body">
					<header class="page-header">
						<h2>सर्वेक्षण तपशील</h2>
					
						<div class="right-wrapper pull-right">
							<ol class="breadcrumbs">
								<li>
									<a href="/">
										<i class="fa fa-home"></i>
									</a>
								</li>
								<li><span>टेबल</span></li>
								<li><span>सर्वेक्षण</span></li>
							</ol>
					
							<a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
						</div>
					</header>

					<!-- start: page -->
						<section class="panel">
							<header class="panel-heading">
								<div class="panel-actions">
									<a href="#" class="fa fa-caret-down"></a>
									<a href="#" class="fa fa-times"></a>
								</div>
						
								<h2 class="panel-title">सर्वेक्षण तपशील</h2>
							</header>
							<div class="panel-body">
								<table class="table table-bordered table-striped mb-none" id="datatable-default">
									<thead>
										<tr>
											<th>सर्वेक्षण क्र. </th>
											<th>जिल्हा नाव</th>
											<th>तालुका</th>
											<th>ग्रामपंचायत</th>
											
											<th>स्वयंघोषणापत्र  करुन देणार</th>
											<th class="hidden-phone">स्वयंघोषणापत्र  करुन घेणार</th>
											<th class="hidden-phone">भोगवटदाराचे नांव</th>
											<th class="hidden-phone">सिटीसव्‍ह मिळकत धारकाचे नांव </th>
											<th class="hidden-phone">मोबाइल नं</th>
											<th class="hidden-phone">आधार नं</th>
											
											<th class="hidden-phone">Edit</th>
											<th class="hidden-phone">Delete</th>
											
											<th class="hidden-phone">View Details</th>
											<th class="hidden-phone">Print Details</th>
											
										</tr>
									</thead>
									<tbody>
									    <?php
									    $i=0;
									    ?>
										@foreach($survey_i as $sur)
										<tr class="gradeX">
											<td>{{$sur->id}}</td>
											<td><?php echo $jillanamesss[$i];?></td>
											<td><?php echo $areanamesss[$i];?></td>
											<td><?php echo $gramnamesss[$i];?></td>
											<td>{{$sur->name}}</td>
											
											<td class="center hidden-phone">{{$sur->gram_name}}</td>
											
											<td class="center hidden-phone">{{$sur->name2}}</td>
											<td class="center hidden-phone">{{$sur->survey_name}}</td>
											<td class="center hidden-phone">{{$sur->mbl}}</td>
											<td class="center hidden-phone">{{$sur->adhar}}</td>
											
											
											<td class="actions"><button class="btn btn-primary"><a href="{{route('survey_info.edit',$sur->id)}}" class="on-default edit-row" style="text-decoration:none;color:white;">Edit</a></button></td>
											<td class="actions">
												<form method="post" action="{{route('survey_info.destroy',$sur->id)}}">
												@csrf
												@method('DELETE')
												<input type="submit" name="delete" value="Delete" class="btn btn-danger">
												</form>
											</td>
											<td class="actions"><button class="btn btn-success"><a href="{{route('survey_info.show',$sur->id)}}" class="on-default edit-row" style="text-decoration:none;color:white;">View Details</a></button></td>
											<td><a href="/printdetails/{{$sur->id}}">Print Details</a></td>
										</tr>
										<?php
										$i++;
										?>
										@endforeach
									</tbody>
								</table>
							</div>
						</section>
						</section>
						
</div>	
			@stop