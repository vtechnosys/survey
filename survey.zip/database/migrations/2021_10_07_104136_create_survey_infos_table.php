<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSurveyInfosTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('survey_infos', function (Blueprint $table) {
            $table->id();
            			$table->string('area_id');
			$table->string('name');
			$table->string('jilla_id');
			$table->string('taluka_id');
			$table->string('gram_id');
			$table->string('gram_name');
			$table->string('name2');
			$table->string('survey_name');
			$table->string('mbl');
			$table->string('adhar');
			$table->string('old_tax_no');
			$table->string('s_s_no');
			$table->string('s_s_m');
			$table->string('group_no');
			$table->string('plot_no');
			$table->string('total_sqft');
			$table->string('north_south');
			$table->string('east_west');
			$table->string('details');
			$table->string('north');
			$table->string('south');
			$table->string('east');
			$table->string('west');
			$table->string('gate');
			$table->string('wife_mbl');
			$table->string('wife_adhar');
			$table->string('img');
			$table->string('mapimg');
			$table->string('nal');
			$table->string('washroom');
			$table->string('status');
			$table->string('tax_number');
			$table->string('date');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('survey_infos');
    }
}
